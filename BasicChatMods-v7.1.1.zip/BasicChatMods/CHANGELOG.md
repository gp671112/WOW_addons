# BasicChatMods

## [v7.1.1](https://github.com/funkydude/BasicChatMods/tree/v7.1.1) (2016-10-26) [](#top)
[Full Changelog](https://github.com/funkydude/BasicChatMods/compare/v7.1.0...v7.1.1)

-   buttons: remove compat  
-   history: large cleanup to the code that remembers chat after doing a UI reload, thanks to patch 7.1  
-   history: SetMaxLines no longer clears the chat frame, remove giant block of code.  
