# BasicChatMods

## [v7.1.8](https://github.com/funkydude/BasicChatMods/tree/v7.1.8) (2017-02-14) [](#top)
[Full Changelog](https://github.com/funkydude/BasicChatMods/compare/v7.1.7...v7.1.8)

- urlcopy: More matching tweaks  
