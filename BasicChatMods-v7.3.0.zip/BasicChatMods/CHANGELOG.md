# BasicChatMods

## [v7.3.0](https://github.com/funkydude/BasicChatMods/tree/v7.3.0) (2017-08-29)
[Full Changelog](https://github.com/funkydude/BasicChatMods/compare/v7.2.1...v7.3.0)

- bump toc  
- remove compat code  
