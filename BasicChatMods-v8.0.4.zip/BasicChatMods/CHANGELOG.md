# BasicChatMods

## [v8.0.4](https://github.com/funkydude/BasicChatMods/tree/v8.0.4) (2018-07-27)
[Full Changelog](https://github.com/funkydude/BasicChatMods/compare/v8.0.3...v8.0.4)

- config: Fix some of the sliders erroring.  
- Fix not being able to drag some chat frames to the very edge since BfA.  
- channelnames: Replacements for channel names now work with more than 10 custom channels.  
