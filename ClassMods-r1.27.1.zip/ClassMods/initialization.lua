﻿--
-- ClassMods - addon initialization
--

ClassMods		= LibStub("AceAddon-3.0"):NewAddon("ClassMods", "AceEvent-3.0")
ClassMods.F	= {}