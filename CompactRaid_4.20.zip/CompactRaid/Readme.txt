Slash commands:

/craid
/compactraid