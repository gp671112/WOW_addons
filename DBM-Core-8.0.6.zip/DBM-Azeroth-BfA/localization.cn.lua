-- Mini Dragon(projecteurs@gmail.com)
-- 夏一可
-- Blizzard Entertainment
-- Last update: 2018/05/02

if GetLocale() ~= "zhCN" then return end
local L

-----------------------
-- T'zane --
-----------------------
L= DBM:GetModLocalization(2139)

-----------------------
-- Ji'arak --
-----------------------
L= DBM:GetModLocalization(2141)

-----------------------
-- Hailstone Construct --
-----------------------
L= DBM:GetModLocalization(2197)

-----------------------
-- Azurethos, The Winged Typhoon --
-----------------------
L= DBM:GetModLocalization(2199)

-----------------------
-- Doom's Howl --
-----------------------
L= DBM:GetModLocalization(2213)

-----------------------
-- Warbringer Yenajz --
-----------------------
L= DBM:GetModLocalization(2198)

-----------------------
-- Dunegorger Kraulok --
-----------------------
L= DBM:GetModLocalization(2210)
