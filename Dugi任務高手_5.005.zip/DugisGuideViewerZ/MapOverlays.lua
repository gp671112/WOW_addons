local MOD = DugisGuideViewer
local _
local MapOverlays = MOD:RegisterModule("MapOverlays")
MapOverlays.essential = true
local harvestingDataMode = false

local HBDMigrate = LibStub("HereBeDragons-Migrate")

function MapOverlays:Initialize()
	local defaults = {
		global = {
			overlayData = {
				["AhnQirajTheFallenKingdom"] = {
					["AQKingdom"] = 121271159,
				},
				["Arathi"] = {
					["BoulderfistHall"] = 394406398204,
					["Bouldergor"] = 132249835769,
					["CircleofEastBinding"] = 135822293175,
					["CircleofInnerBinding"] = 335218445540,
					["CircleofWestBinding"] = 25859226844,
					["CirecleofOuterBinding"] = 293479837911,
					["DabyriesFarmstead"] = 155042680018,
					["FaldirsCove"] = 429577744657,
					["GalensFall"] = 154619135188,
					["GoShekFarm"] = 267812856114,
					["Hammerfall"] = 127311035662,
					["NorthfoldManor"] = 112881578211,
					["RefugePoint"] = 156000073924,
					["StromgardeKeep"] = 288858884380,
					["ThandolSpan"] = 446950535405,
					["WitherbarkVillage"] = 385972662532,
				},
				["Ashenvale"] = {
					["Astranaar"] = 176361323771,
					["BoughShadow"] = 159790615718,
					["FallenSkyLake"] = 413945581855,
					["FelfireHill"] = 341125182741,
					["LakeFalathim"] = 159031468216,
					["MaelstrasPost"] = 197502198,
					["NightRun"] = 272280847581,
					["OrendilsRetreat"] = 150203636,
					["RaynewoodRetreat"] = 237801570535,
					["Satyrnaar"] = 166086291691,
					["SilverwindRefuge"] = 360058245467,
					["TheHowlingVale"] = 104649178437,
					["TheRuinsofStardust"] = 355629022444,
					["TheShrineofAssenia"] = 295321234738,
					["TheZoramStrand"] = 399622,
					["ThistlefurVillage"] = 84019496250,
					["ThunderPeak"] = 130318391499,
					["WarsongLumberCamp"] = 285350264039,
				},
				["Aszhara"] = {
					["BearsHead"] = 151516315904,
					["BilgewaterHarbor"] = 136779789899,
					["BitterReaches"] = 500424001,
					["BlackmawHold"] = 57122499844,
					["DarnassianBaseCamp"] = 3581155571,
					["GallywixPleasurePalace"] = 238444321018,
					["LakeMennar"] = 405057806546,
					["OrgimmarRearGate"] = 369390537056,
					["RavencrestMonument"] = 431069867303,
					["RuinsofArkkoran"] = 130525889755,
					["RuinsofEldarath"] = 246126195930,
					["StormCliffs"] = 433144963279,
					["TheSecretLab"] = 425572127928,
					["TheShatteredStrand"] = 180720313550,
					["TowerofEldara"] = 24339891506,
				},
				["AzuremystIsle"] = {
					["AmmenFord"] = 300114247936,
					["AmmenVale"] = 112222274011,
					["AzureWatch"] = 267763581184,
					["BristlelimbVillage"] = 389950996736,
					["Emberglade"] = 26281771264,
					["FairbridgeStrand"] = 373424384,
					["GreezlesCamp"] = 376341528832,
					["MoongrazeWoods"] = 196965826816,
					["OdesyusLanding"] = 406243770624,
					["PodCluster"] = 327786168576,
					["PodWreckage"] = 375220600960,
					["SiltingShore"] = 3526623488,
					["SilvermystIsle"] = 478913198336,
					["StillpineHold"] = 52996342016,
					["TheExodar"] = 91346174464,
					["ValaarsBerth"] = 325528584448,
					["WrathscalePoint"] = 452276247808,
				},
				["Badlands"] = {
					["AgmondsEnd"] = 338470208854,
					["AngorFortress"] = 73255845149,
					["ApocryphansRest"] = 70867322108,
					["CampBoff"] = 236650430738,
					["CampCagg"] = 301721808211,
					["CampKosh"] = 20929843436,
					["DeathwingScar"] = 191309866312,
					["HammertoesDigsite"] = 124985217233,
					["LethlorRavine"] = 59615319509,
					["TheDustbowl"] = 106451727574,
					["Uldaman"] = 352536842,
				},
				["Barrens"] = {
					["BoulderLodeMine"] = 8052229398,
					["DreadmistPeak"] = 111973436657,
					["FarWatchPost"] = 139094995151,
					["GroldomFarm"] = 136835196147,
					["MorshanRampart"] = 6713204997,
					["Ratchet"] = 407521901787,
					["TheCrossroads"] = 295658783977,
					["TheDryHills"] = 61325195547,
					["TheForgottenPools"] = 223443419582,
					["TheMerchantCoast"] = 490209497403,
					["TheSludgeFen"] = 6865282305,
					["TheStagnantOasis"] = 407309157712,
					["TheWailingCaverns"] = 341609616761,
					["ThornHill"] = 273235025135,
				},
				["BladesEdgeMountains"] = {
					["BashirLanding"] = 442761472,
					["BladedGulch"] = 158493573376,
					["BladesipreHold"] = 173202205952,
					["BloodmaulCamp"] = 102437748992,
					["BloodmaulOutpost"] = 398717134080,
					["BrokenWilds"] = 117806727424,
					["CircleofWrath"] = 225946370304,
					["DeathsDoor"] = 267899014400,
					["ForgeCampAnger"] = 158454776224,
					["ForgeCampTerror"] = 446827852288,
					["ForgeCampWrath"] = 189245161728,
					["Grishnath"] = 30364926208,
					["GruulsLayer"] = 87525949696,
					["JaggedRidge"] = 444997040384,
					["MokNathalVillage"] = 319591547136,
					["RavensWood"] = 59280458240,
					["RazorRidge"] = 357041520896,
					["RidgeofMadness"] = 277606721792,
					["RuuanWeald"] = 105729491200,
					["Skald"] = 76941623552,
					["Sylvanaar"] = 376113002752,
					["TheCrystalpine"] = 613679360,
					["ThunderlordStronghold"] = 292482855168,
					["VeilLashh"] = 459845910784,
					["VeilRuuan"] = 162725495040,
					["VekhaarStand"] = 436598997248,
					["VortexPinnacle"] = 221365352704,
				},
				["BlastedLands"] = {
					["AltarofStorms"] = 118347730158,
					["DreadmaulHold"] = 270743824,
					["DreadmaulPost"] = 195764089067,
					["NethergardeKeep"] = 6998406439,
					["NethergardeSupplyCamps"] = 457383107,
					["RISEOFTHEDEFILER"] = 109915056296,
					["SerpentsCoil"] = 104634440922,
					["Shattershore"] = 98316859632,
					["SunveilExcursion"] = 401984465129,
					["Surwich"] = 509302996167,
					["TheDarkPortal"] = 192585967986,
					["TheRedReaches"] = 288322062604,
					["TheTaintedForest"] = 334072485212,
					["TheTaintedScar"] = 188056045876,
				},
				["BloodmystIsle"] = {
					["AmberwebPass"] = 66618654976,
					["Axxarien"] = 146340577536,
					["BlacksiltShore"] = 457599863296,
					["Bladewood"] = 224797131008,
					["BloodWatch"] = 277483880704,
					["BloodscaleIsle"] = 275678232815,
					["BristlelimbEnclave"] = 440806932736,
					["KesselsCrossing"] = 566404199909,
					["Middenvale"] = 436373553408,
					["Mystwood"] = 518941500672,
					["Nazzivian"] = 434054103296,
					["RagefeatherRidge"] = 126132420864,
					["RuinsofLorethAran"] = 232511504640,
					["TalonStand"] = 84441039104,
					["TelathionsCamp"] = 232117108864,
					["TheBloodcursedReef"] = 58746732800,
					["TheBloodwash"] = 29307961600,
					["TheCrimsonReach"] = 93997760768,
					["TheCryoCore"] = 306323915008,
					["TheFoulPool"] = 146260885760,
					["TheHiddenReef"] = 42091151616,
					["TheLostFold"] = 505186294016,
					["TheVectorCoil"] = 255596083712,
					["TheWarpPiston"] = 31611683072,
					["VeridianPoint"] = 668205312,
					["VindicatorsRest"] = 260089053440,
					["WrathscaleLair"] = 363552047360,
					["WyrmscarIsland"] = 88689869056,
				},
				["BoreanTundra"] = {
					["AmberLedge"] = 150664861940,
					["BorGorokOutpost"] = 329461132,
					["Coldarra"] = 52819404,
					["DeathsStand"] = 195088899361,
					["GarroshsLanding"] = 255711373579,
					["Kaskala"] = 230314799489,
					["RiplashStrand"] = 411550615934,
					["SteeljawsCaravan"] = 71283571956,
					["TempleCityOfEnKilah"] = 16853012770,
					["TheDensOfDying"] = 12505531595,
					["TheGeyserFields"] = 503667063,
					["TorpsFarm"] = 254762307770,
					["ValianceKeep"] = 283947350275,
					["WarsongStronghold"] = 254822078724,
				},
				["BurningSteppes"] = {
					["AltarofStorms"] = 368822,
					["BlackrockMountain"] = 83235097,
					["BlackrockPass"] = 277465164074,
					["BlackrockStronghold"] = 246809920,
					["Dracodar"] = 254477253994,
					["DreadmaulRock"] = 162730876178,
					["MorgansVigil"] = 274449462655,
					["PillarofAsh"] = 274069878034,
					["RuinsofThaurissan"] = 441813316,
					["TerrorWingPath"] = 8193922398,
				},
				["CrystalsongForest"] = {
					["ForlornWoods"] = 135950880,
					["SunreaversCommand"] = 43512087998,
					["TheAzureFront"] = 261993439648,
					["TheDecrepitFlow"] = 227616,
					["TheGreatTree"] = 97710772476,
					["TheUnboundThicket"] = 113267668470,
					["VioletStand"] = 188978871560,
					["WindrunnersOverlook"] = 411708978734,
				},
				["Darkshore"] = {
					["AmethAran"] = 354643232070,
					["EyeoftheVortex"] = 256939065674,
					["Lordanel"] = 58392339733,
					["Nazjvel"] = 501654693108,
					["RuinsofAuberdine"] = 195714812107,
					["RuinsofMathystra"] = 30607154376,
					["ShatterspearVale"] = 17805067514,
					["ShatterspearWarcamp"] = 592596213,
					["TheMastersGlaive"] = 518907946287,
					["WildbendRiver"] = 406168208698,
					["WitheringThicket"] = 127021607240,
				},
				["DeadwindPass"] = {
					["DeadmansCrossing"] = 87566953,
					["Karazhan"] = 332956801537,
					["TheVice"] = 223792792926,
				},
				["Deepholm"] = {
					["CrimsonExpanse"] = 13451542990,
					["DeathwingsFall"] = 319477341638,
					["NeedlerockChasm"] = 21339514,
					["NeedlerockSlag"] = 156766598514,
					["ScouredReach"] = 470056452,
					["StoneHearth"] = 337155295603,
					["StormsFuryWreckage"] = 411723658532,
					["TempleOfEarth"] = 190353597795,
					["ThePaleRoost"] = 89408979,
					["TheShatteredField"] = 470447004078,
					["TherazanesThrone"] = 455242002,
					["TwilightOverlook"] = 451569508763,
					["TwilightTerrace"] = 412628490477,
				},
				["Desolace"] = {
					["CenarionWildlands"] = 167939175736,
					["GelkisVillage"] = 507023397138,
					["KodoGraveyard"] = 293509225722,
					["MagramTerritory"] = 183179137313,
					["MannorocCoven"] = 383725657414,
					["NijelsPoint"] = 601097447,
					["RanzjarIsle"] = 220345505,
					["Sargeron"] = 687117629,
					["ShadowbreakRavine"] = 432312428836,
					["ShadowpreyVillage"] = 396359937246,
					["ShokThokar"] = 343141610805,
					["SlitherbladeShore"] = 25988258130,
					["TethrisAran"] = 418530578,
					["ThargadsCamp"] = 404015474900,
					["ThunderAxeFortress"] = 53074932956,
					["ValleyofSpears"] = 210631937345,
				},
				["Dragonblight"] = {
					["AgmarsHammer"] = 218240346348,
					["Angrathar"] = 220449074,
					["ColdwindHeights"] = 422800597,
					["EmeraldDragonshrine"] = 389264140484,
					["GalakrondsRest"] = 127155799298,
					["IcemistVillage"] = 177308255467,
					["LakeIndule"] = 336309039460,
					["LightsRest"] = 8253626667,
					["Naxxramas"] = 172523536695,
					["NewHearthglen"] = 385043666134,
					["ObsidianDragonshrine"] = 111937793328,
					["RubyDragonshrine"] = 223730683068,
					["ScarletPoint"] = 8113195243,
					["TheCrystalVice"] = 510921957,
					["TheForgottenShore"] = 357214484781,
					["VenomSpite"] = 284161167586,
					["WestwindRefugeeCamp"] = 200834067685,
					["WyrmrestTemple"] = 235624826173,
				},
				["DreadWastes"] = {
					["BREWGARDEN"] = 368273658,
					["BRINYMUCK"] = 334158379333,
					["CLUTCHESOFSHEKZEER"] = 134575618257,
					["DREADWATERLAKE"] = 336539635010,
					["HEARTOFFEAR"] = 131197080838,
					["HORRIDMARCH"] = 240980789571,
					["KLAXXIVESS"] = 118592059628,
					["KYPARIVOR"] = 508754245,
					["RIKKITUNVILLAGE"] = 34607392986,
					["SOGGYSGAMBLE"] = 436411286796,
					["TERRACEOFGURTHAN"] = 99406293201,
					["ZANVESS"] = 413560761634,
				},
				["DunMorogh"] = {
					["AmberstillRanch"] = 242216000761,
					["ColdridgePass"] = 365449990369,
					["ColdridgeValley"] = 393094674830,
					["FrostmaneFront"] = 275370032354,
					["FrostmaneHold"] = 243792078261,
					["Gnomeregan"] = 28991355289,
					["GolBolarQuarry"] = 309933108422,
					["HelmsBedLake"] = 288559966426,
					["IceFlowLake"] = 276142316,
					["Ironforge"] = 417688952,
					["IronforgeAirfield"] = 660946228,
					["Kharanos"] = 236694204600,
					["NorthGateOutpost"] = 46973434093,
					["TheGrizzledDen"] = 308556234963,
					["TheShimmeringDeep"] = 142150445227,
					["TheTundridHills"] = 329172378798,
				},
				["Durotar"] = {
					["DrygulchRavine"] = 64859869420,
					["EchoIsles"] = 443905473866,
					["NorthwatchFoothold"] = 472864945314,
					["Orgrimmar"] = 324179203,
					["RazorHill"] = 169029635296,
					["RazormaneGrounds"] = 283784673528,
					["SenjinVillage"] = 436418568384,
					["SkullRock"] = 459437264,
					["SouthfuryWatershed"] = 187127003380,
					["ThunderRidge"] = 51849160924,
					["TiragardeKeep"] = 320459710674,
					["ValleyOfTrials"] = 335326480638,
				},
				["Duskwood"] = {
					["AddlesStead"] = 373696012587,
					["BrightwoodGrove"] = 120780635415,
					["Darkshire"] = 138110363977,
					["ManorMistmantle"] = 131689797851,
					["RacenHill"] = 313633436877,
					["RavenHillCemetary"] = 141829657923,
					["TheDarkenedBank"] = 27991977891,
					["TheHushedBank"] = 163209071805,
					["TheRottingOrchard"] = 395702443299,
					["TheTranquilGardensCemetary"] = 370024894755,
					["TheTwilightGrove"] = 108777574720,
					["TheYorgenFarmstead"] = 425622495465,
					["VulGolOgreMound"] = 381417711884,
				},
				["Dustwallow"] = {
					["AlcazIsland"] = 23236649166,
					["BlackhoofVillage"] = 208854360,
					["BrackenwllVillage"] = 63490483584,
					["DirehornPost"] = 181838066967,
					["Mudsprocket"] = 336195845553,
					["ShadyRestInn"] = 202007353661,
					["TheWyrmbog"] = 396587478452,
					["TheramoreIsle"] = 240013008177,
					["WitchHill"] = 449152270,
				},
				["Dustwallow_terrain1"] = {
					["ALCAZISLAND"] = 23236649166,
					["BLACKHOOFVILLAGE"] = 208854360,
					["BRACKENWLLVILLAGE"] = 63490483584,
					["DIREHORNPOST"] = 181838066967,
					["MUDSPROCKET"] = 336195845553,
					["SHADYRESTINN"] = 202007353661,
					["THERAMOREISLE"] = 240013008177,
					["THEWYRMBOG"] = 396587478452,
					["WITCHHILL"] = 449152270,
				},
				["EasternPlaguelands"] = {
					["Acherus"] = 110333543652,
					["BlackwoodLake"] = 162535808238,
					["CorinsCrossing"] = 310828553402,
					["CrownGuardTower"] = 377154108618,
					["Darrowshire"] = 496290183416,
					["EastwallTower"] = 198135955637,
					["LakeMereldar"] = 458972448010,
					["LightsHopeChapel"] = 291704631492,
					["LightsShieldTower"] = 291394193651,
					["Northdale"] = 66096177417,
					["NorthpassTower"] = 74508861690,
					["Plaguewood"] = 43100927304,
					["QuelLithienLodge"] = 368229653,
					["RuinsOfTheScarletEnclave"] = 317528069384,
					["Stratholme"] = 123914550,
					["Terrordale"] = 10737746178,
					["TheFungalVale"] = 226751635730,
					["TheInfectisScar"] = 283018274993,
					["TheMarrisStead"] = 359843178698,
					["TheNoxiousGlade"] = 59737681193,
					["ThePestilentScar"] = 374064087222,
					["TheUndercroft"] = 490758950168,
					["ThondorilRiver"] = 107374721286,
					["Tyrshand"] = 445211998422,
					["ZulMashar"] = 553828638,
				},
				["Elwynn"] = {
					["BrackwellPumpkinPatch"] = 455824597279,
					["CrystalLake"] = 351551044828,
					["EastvaleLoggingCamp"] = 314270010662,
					["FargodeepMine"] = 451223478541,
					["Goldshire"] = 315939331348,
					["JerodsLanding"] = 462124431590,
					["NorthshireValley"] = 148548919591,
					["RidgepointTower"] = 475336476957,
					["StonecairnLake"] = 200295072084,
					["Stromwind"] = 432640,
					["TowerofAzora"] = 308718847246,
					["WestbrookGarrison"] = 381300303117,
				},
				["EversongWoods"] = {
					["AzurebreezeCoast"] = 245514895616,
					["DuskwitherGrounds"] = 272291332352,
					["EastSanctum"] = 400988307712,
					["ElrendarFalls"] = 429031424128,
					["FairbreezeVilliage"] = 414869356800,
					["FarstriderRetreat"] = 386022899968,
					["GoldenboughPass"] = 503839850752,
					["LakeElrendar"] = 506344969344,
					["NorthSanctum"] = 320353861888,
					["RuinsofSilvermoon"] = 146351063296,
					["RunestoneFalithas"] = 532972482816,
					["RunestoneShandor"] = 530915178752,
					["SatherilsHaven"] = 412656861440,
					["SilvermoonCity"] = 93877436928,
					["StillwhisperPond"] = 337652220160,
					["SunsailAnchorage"] = 434034049280,
					["SunstriderIsle"] = 5573706240,
					["TheGoldenStrand"] = 445795005568,
					["TheLivingWood"] = 451507642496,
					["TheScortchedGrove"] = 544654622976,
					["ThuronsLivery"] = 328056570112,
					["TorWatha"] = 338908513536,
					["TranquilShore"] = 320200769792,
					["WestSanctum"] = 342830088320,
					["Zebwatha"] = 510608475264,
				},
				["Felwood"] = {
					["BloodvenomFalls"] = 248265245017,
					["DeadwoodVillage"] = 542669704365,
					["EmeraldSanctuary"] = 410582733074,
					["FelpawVillage"] = 494044467,
					["IrontreeWoods"] = 59481801989,
					["JadefireGlen"] = 492075960549,
					["JadefireRun"] = 9981598983,
					["Jaedenar"] = 340621705535,
					["MorlosAran"] = 520190345403,
					["RuinsofConstellas"] = 385765038348,
					["ShatterScarVale"] = 115145435479,
					["TalonbranchGlade"] = 61760309457,
				},
				["Feralas"] = {
					["CampMojache"] = 195051090094,
					["DarkmistRuins"] = 308759697580,
					["DireMaul"] = 108956774665,
					["FeathermoonStronghold"] = 254856593625,
					["FeralScar"] = 302200835263,
					["GordunniOutpost"] = 125249418432,
					["GrimtotemCompund"] = 183172819103,
					["LowerWilds"] = 205877626063,
					["RuinsofFeathermoon"] = 246082121936,
					["RuinsofIsildien"] = 380594533582,
					["TheForgottenCoast"] = 368686973122,
					["TheTwinColossals"] = 284506462,
					["WrithingDeep"] = 320658946280,
				},
				["FrostfireRidge"] = {
					["BLADESPIREFORTRESS"] = 125667949924,
					["BLOODMAULSTRONGHOLD"] = 4621296898,
					["BONESOFAGURAK"] = 343288411409,
					["DAGGERMAWRAVINE"] = 98008497407,
					["FROSTWINDDUNES"] = 127097106,
					["GRIMFROSTHILL"] = 226111990962,
					["GROMBOLASH"] = 35940187353,
					["GROMGAR"] = 347348489498,
					["HORDEGARRISON"] = 351466161419,
					["IRONSIEGEWORKS"] = 168209717577,
					["IRONWAYSTATION"] = 327089994951,
					["MAGNAROK"] = 36072347861,
					["NOGARRISON"] = 351466161419,
					["STONEFANGOUTPOST"] = 302042512635,
					["THEBONESLAG"] = 206462732544,
					["THECRACKLINGPLAINS"] = 147563255050,
					["WORGOL"] = 313608348989,
				},
				["Ghostlands"] = {
					["AmaniPass"] = 249735598484,
					["BleedingZiggurat"] = 255743754496,
					["DawnstarSpire"] = 603193771,
					["Deatholme"] = 402753099264,
					["ElrendarCrossing"] = 342098432,
					["FarstriderEnclave"] = 146629984685,
					["GoldenmistVillage"] = 46662144,
					["HowlingZiggurat"] = 235506435328,
					["IsleofTribulations"] = 613679360,
					["SanctumoftheMoon"] = 135511933184,
					["SanctumoftheSun"] = 161531560192,
					["SuncrownVillage"] = 482607616,
					["ThalassiaPass"] = 436321130752,
					["Tranquillien"] = 2530738432,
					["WindrunnerSpire"] = 308206108928,
					["WindrunnerVillage"] = 125691232512,
					["ZebNowa"] = 254965890560,
				},
				["Gilneas"] = {
					["CrowleyOrchard"] = 458761607378,
					["Duskhaven"] = 357841422622,
					["EmberstoneMine"] = 46841298201,
					["GilneasCity"] = 225992514842,
					["Greymanemanor"] = 217043944692,
					["HammondFarmstead"] = 378132476098,
					["HaywardFishery"] = 482417536177,
					["Keelharbor"] = 102318299416,
					["KorothsDen"] = 414876709086,
					["NorthernHeadlands"] = 406120715,
					["NorthgateWoods"] = 15538104602,
					["StormglenVillage"] = 499831221569,
					["TempestsReach"] = 312069154142,
					["TheBlackwald"] = 423582990616,
					["TheHeadlands"] = 168116552,
				},
				["Gorgrond"] = {
					["BASTIONRISE"] = 544684016964,
					["BEASTWATCH"] = 398759986342,
					["EASTERNRUIN"] = 279723574482,
					["EVERMORN"] = 477036205353,
					["FOUNDRY"] = 79934223571,
					["FOUNDRYSOUTH"] = 196970991833,
					["GRONNCANYON"] = 228977788183,
					["HIGHLANDPASS"] = 78957055261,
					["HIGHPASS"] = 268866651345,
					["IRONDOCKS"] = 367186235,
					["MUSHROOMS"] = 347284379901,
					["STONEMAULARENA"] = 359975274713,
					["STONEMAULSOUTH"] = 446965102800,
					["STRIPMINE"] = 83005513978,
					["TANGLEHEART"] = 399905092870,
				},
				["GrizzlyHills"] = {
					["AmberpineLodge"] = 262220843286,
					["BlueSkyLoggingGrounds"] = 138756205817,
					["CampOneqwah"] = 147677521220,
					["ConquestHold"] = 329656867148,
					["DrakTheronKeep"] = 49392416126,
					["DrakilJinRuins"] = 44660191583,
					["DunArgol"] = 276525629895,
					["GraniteSprings"] = 222272127332,
					["GrizzleMaw"] = 201165344038,
					["RageFangShrine"] = 316007623131,
					["ThorModan"] = 533977417,
					["UrsocsDen"] = 34707083592,
					["VentureBay"] = 495014067474,
					["Voldrune"] = 452230110491,
				},
				["Hellfire"] = {
					["DenofHaalesh"] = 442572734720,
					["ExpeditionArmory"] = 443729313280,
					["FalconWatch"] = 350232074752,
					["FallenSkyRidge"] = 152507252992,
					["ForgeCampRage"] = 27345289728,
					["HellfireCitadel"] = 225840670976,
					["HonorHold"] = 320467108096,
					["MagharPost"] = 118327869696,
					["PoolsofAggonar"] = 48660742400,
					["RuinsofShanaar"] = 311411730688,
					["TempleofTelhamat"] = 163249127936,
					["TheLegionFront"] = 138046603520,
					["TheStairofDestiny"] = 168277049600,
					["Thrallmar"] = 165846188288,
					["ThroneofKiljaeden"] = 6942884352,
					["VoidRidge"] = 395876499712,
					["WarpFields"] = 438409892096,
					["ZethGor"] = 462317402534,
				},
				["HillsbradFoothills"] = {
					["AzurelodeMine"] = 428724115636,
					["ChillwindPoint"] = 73596673471,
					["CorrahnsDagger"] = 240965025927,
					["CrushridgeHold"] = 108933542022,
					["DalaranCrater"] = 147209828668,
					["DandredsFold"] = 357680386,
					["DarrowHill"] = 300019777683,
					["DunGarok"] = 440802740493,
					["DurnholdeKeep"] = 233594883509,
					["GallowsCorner"] = 150796913819,
					["GavinsNaze"] = 273091265652,
					["GrowlessCave"] = 205461266603,
					["HillsbradFields"] = 324470488366,
					["LordamereInternmentCamp"] = 232131828986,
					["MistyShore"] = 45433922718,
					["NethanderSteed"] = 401032335564,
					["PurgationIsle"] = 542449478800,
					["RuinsOfAlterac"] = 91632096445,
					["SlaughterHollow"] = 59488985236,
					["SoferasNaze"] = 178748803220,
					["SouthpointTower"] = 332922091832,
					["Southshore"] = 378358951141,
					["Strahnbrad"] = 47774369043,
					["TarrenMill"] = 243183856805,
					["TheHeadland"] = 274213261417,
					["TheUplands"] = 462586068,
				},
				["Hinterlands"] = {
					["AeriePeak"] = 253403344110,
					["Agolwatha"] = 171109986512,
					["JinthaAlor"] = 359140721951,
					["PlaguemistRavine"] = 112882636991,
					["QuelDanilLodge"] = 194578173169,
					["Seradane"] = 5867101487,
					["ShadraAlor"] = 407179038960,
					["Shaolwatha"] = 223931012377,
					["SkulkRock"] = 209893698736,
					["TheAltarofZul"] = 368667988193,
					["TheCreepingRuin"] = 270992088263,
					["TheOverlookCliffs"] = 287399363828,
					["ValorwindLake"] = 289136660679,
					["Zunwatha"] = 305102292194,
				},
				["HowlingFjord"] = {
					["AncientLift"] = 377242188977,
					["ApothecaryCamp"] = 39832528135,
					["BaelgunsExcavationSite"] = 351765054708,
					["Baleheim"] = 183140267182,
					["CampWinterHoof"] = 371410143,
					["CauldrosIsle"] = 173386418357,
					["EmberClutch"] = 218266599637,
					["ExplorersLeagueOutpost"] = 361390891240,
					["FortWildervar"] = 513999099,
					["GiantsRun"] = 600099114,
					["Gjalerbron"] = 236123378,
					["Halgrind"] = 223754853563,
					["IvaldsRuin"] = 240145081537,
					["Kamagua"] = 298604307789,
					["NewAgamand"] = 386982531356,
					["Nifflevar"] = 258322153650,
					["ScalawagPoint"] = 440410573150,
					["Skorn"] = 116324016366,
					["SteelGate"] = 107607138526,
					["TheTwistedGlade"] = 61643901194,
					["UtgardeKeep"] = 232428796152,
					["VengeanceLanding"] = 27540146399,
					["WestguardKeep"] = 193368125787,
				},
				["HrothgarsLanding"] = {
				},
				["Hyjal"] = {
					["ArchimondesVengeance"] = 5704560910,
					["AshenLake"] = 83758582042,
					["DarkwhisperGorge"] = 138154564928,
					["DireforgeHill"] = 211845035278,
					["GatesOfSothann"] = 344249940240,
					["Nordrassil"] = 411373081,
					["SethriasRoost"] = 468297425173,
					["ShrineOfGoldrinn"] = 18375574819,
					["TheRegrowth"] = 271711534521,
					["TheScorchedPlain"] = 232359469421,
					["TheThroneOfFlame"] = 406208154019,
				},
				["IcecrownGlacier"] = {
					["Aldurthar"] = 40101076341,
					["ArgentTournamentGround"] = 32858407226,
					["Corprethar"] = 421265625396,
					["IcecrownCitadel"] = 500774938932,
					["Jotunheim"] = 131020056969,
					["OnslaughtHarbor"] = 179315159244,
					["Scourgeholme"] = 287412829429,
					["SindragosasFall"] = 33942756652,
					["TheBombardment"] = 194911653112,
					["TheBrokenFront"] = 353846402331,
					["TheConflagration"] = 327834355939,
					["TheFleshwerks"] = 312687750363,
					["TheShadowVault"] = 16443129055,
					["Valhalas"] = 53914878190,
					["ValleyofEchoes"] = 419509265677,
					["Ymirheim"] = 296818523359,
				},
				["Kezan"] = {
					["KEZANMAP"] = 4295648234,
				},
				["Krasarang"] = {
					["AnglersOutpost"] = 220688746761,
					["CradleOfChiJi"] = 403911731472,
					["DojaniRiver"] = 3759433918,
					["FallsongRiver"] = 82907112662,
					["LostDynasty"] = 29608926425,
					["NayeliLagoon"] = 400865607926,
					["RedwingRefuge"] = 67978405076,
					["RuinsOfDojan"] = 47710600396,
					["RuinsOfKorja"] = 94620757203,
					["TempleOfTheRedCrane"] = 231169330395,
					["TheDeepwild"] = 63767474364,
					["TheForbiddenJungle"] = 84825911553,
					["TheSouthernIsles"] = 286713505020,
					["UngaIngoo"] = 535069632770,
					["ZhusBastion"] = 641937714,
					["krasarangCove"] = 21136421150,
				},
				["Krasarang_terrain1"] = {
					["ANGLERSOUTPOST"] = 215320042843,
					["CRADLEOFCHIJI"] = 403911731472,
					["DOJANIRIVER"] = 3759433918,
					["FALLSONGRIVER"] = 82907112662,
					["KRASARANGCOVE"] = 21136446759,
					["LOSTDYNASTY"] = 29608926425,
					["NAYELILAGOON"] = 400865607926,
					["REDWINGREFUGE"] = 67978405076,
					["RUINSOFDOJAN"] = 47710600396,
					["RUINSOFKORJA"] = 94620757203,
					["TEMPLEOFTHEREDCRANE"] = 231169330395,
					["THEDEEPWILD"] = 63767474364,
					["THEFORBIDDENJUNGLE"] = 84825911553,
					["THESOUTHERNISLES"] = 286689404179,
					["UNGAINGOO"] = 535069632770,
					["ZHUSBASTION"] = 641937714,
				},
				["KunLaiSummit"] = {
					["BinanVillage"] = 505295345904,
					["FireboughNook"] = 532913762528,
					["GateoftheAugust"] = 543784339717,
					["Iseoflostsouls"] = 4926448899,
					["Kotapeak"] = 386791638268,
					["Mogujia"] = 441792545021,
					["MountNeverset"] = 283707130169,
					["MuskpawRanch"] = 336713750757,
					["PeakOfSerenity"] = 67995194655,
					["ShadoPanMonastery"] = 98876917121,
					["TEMPLEOFTHEWHITETIGER"] = 183151890682,
					["TheBurlapTrail"] = 333277581622,
					["ValleyOfEmperors"] = 205559940320,
					["ZouchinVillage"] = 69246086442,
				},
				["LakeWintergrasp"] = {
				},
				["LochModan"] = {
					["GrizzlepawRidge"] = 348149487889,
					["IronbandsExcavationSite"] = 318332243341,
					["MogroshStronghold"] = 56410498342,
					["NorthgatePass"] = 17073471,
					["SilverStreamMine"] = 231993569,
					["StonesplinterValley"] = 370626828561,
					["StronewroughtDam"] = 355672397,
					["TheFarstriderLodge"] = 225010028893,
					["TheLoch"] = 87330089290,
					["Thelsamar"] = 156766608839,
					["ValleyofKings"] = 333934060854,
				},
				["Moonglade"] = {
					["LakeEluneara"] = 293361483183,
					["Nighthaven"] = 145343369562,
					["ShrineofRemulos"] = 97929961743,
					["StormrageBarrowDens"] = 226054465811,
				},
				["Mulgore"] = {
					["BaeldunDigsite"] = 236460376282,
					["BloodhoofVillage"] = 293466242350,
					["PalemaneRock"] = 344931382444,
					["RavagedCaravan"] = 240974468283,
					["RedCloudMesa"] = 430870634942,
					["RedRocks"] = 46710056122,
					["StonetalonPass"] = 210952429,
					["TheGoldenPlains"] = 108917907642,
					["TheRollingPlains"] = 313011719428,
					["TheVentureCoMine"] = 148732424400,
					["ThunderBluff"] = 66790362485,
					["ThunderhornWaterWell"] = 217245195465,
					["WildmaneWaterWell"] = 347254974,
					["WindfuryRidge"] = 419637470,
					["WinterhoofWaterWell"] = 365543220398,
				},
				["Nagrand"] = {
					["BurningBladeRUins"] = 359322171648,
					["ClanWatch"] = 390326386944,
					["ForgeCampFear"] = 266326151680,
					["ForgeCampHate"] = 165526372608,
					["Garadar"] = 153997279488,
					["Halaa"] = 207583707392,
					["KilsorrowFortress"] = 459073111296,
					["LaughingSkullRuins"] = 56202887424,
					["OshuGun"] = 358806272512,
					["RingofTrials"] = 287248220416,
					["SouthwindCleft"] = 277435646208,
					["SunspringPost"] = 213904523520,
					["Telaar"] = 419165372672,
					["ThroneoftheElements"] = 57437061376,
					["TwilightRidge"] = 114901385472,
					["WarmaulHill"] = 34524627200,
					["WindyreedPass"] = 85452914944,
					["WindyreedVillage"] = 250880459008,
					["ZangarRidge"] = 58272776448,
				},
				["NagrandDraenor"] = {
					["ANCESTRAL"] = 278349937898,
					["BROKENPRECIPICE"] = 13153570097,
					["ELEMENTALS"] = 616843550,
					["GROMMASHAR"] = 394692703488,
					["HALLVALOR"] = 127505125612,
					["HIGHMAUL"] = 447959,
					["IRONFISTHARBOR"] = 380401600748,
					["LOKRATH"] = 201190503740,
					["MARGOKS"] = 408811766009,
					["MUSHROOMS"] = 27626077434,
					["OSHUGUN"] = 347202660614,
					["RINGOFBLOOD"] = 451181831,
					["RINGOFTRIALS"] = 171273678178,
					["SUNSPRINGWATCH"] = 105554114834,
					["TELAAR"] = 379514536232,
				},
				["Netherstorm"] = {
					["Area52"] = 416864665856,
					["ArklonRuins"] = 426619699456,
					["CelestialRidge"] = 186432880896,
					["EcoDomeFarfield"] = 11152916736,
					["EtheriumStagingGrounds"] = 223842926848,
					["ForgeBaseOG"] = 23871095040,
					["KirinVarVillage"] = 562080924928,
					["ManaforgeBanar"] = 301875989760,
					["ManaforgeCoruu"] = 525434277120,
					["ManaforgeDuro"] = 361265103104,
					["ManafrogeAra"] = 166609551616,
					["Netherstone"] = 21906063616,
					["NetherstormBridge"] = 315818770688,
					["RuinedManaforge"] = 148714553600,
					["RuinsofEnkaat"] = 323461841152,
					["RuinsofFarahlon"] = 52984807936,
					["SocretharsSeat"] = 41042575616,
					["SunfuryHold"] = 484733838592,
					["TempestKeep"] = 305564877209,
					["TheHeap"] = 488803357952,
					["TheScrapField"] = 280620171520,
					["TheStormspire"] = 144194142464,
				},
				["Redridge"] = {
					["AlthersMill"] = 149617368292,
					["CampEverstill"] = 307556975805,
					["GalardellValley"] = 602357164,
					["LakeEverstill"] = 229865941456,
					["LakeridgeHighway"] = 339457966472,
					["Lakeshire"] = 118111863194,
					["RedridgeCanyons"] = 39096733,
					["RendersCamp"] = 224647525,
					["RendersValley"] = 405273873835,
					["ShalewindCanyon"] = 304590688562,
					["StonewatchFalls"] = 324820719932,
					["StonewatchKeep"] = 503746788,
					["ThreeCorners"] = 274878323011,
				},
				["RuinsofGilneas"] = {
					["GilneasPuzzle"] = 685034,
				},
				["STVDiamondMineBG"] = {
					["17467"] = 185973492097,
					["17468"] = 103513553258,
					["17469"] = 310904028324,
					["17470"] = 135884178645,
				},
				["SearingGorge"] = {
					["BlackcharCave"] = 387621113207,
					["BlackrockMountain"] = 455521587504,
					["DustfireValley"] = 616926600,
					["FirewatchRidge"] = 80531039597,
					["GrimsiltWorksite"] = 259328846265,
					["TannerCamp"] = 386980434491,
					["TheCauldron"] = 183853490657,
					["ThoriumPoint"] = 41069884845,
				},
				["ShadowmoonValley"] = {
					["AltarofShatar"] = 100403511552,
					["CoilskarPoint"] = 8955363840,
					["EclipsePoint"] = 333219994112,
					["IlladarPoint"] = 275028115712,
					["LegionHold"] = 166539559424,
					["NetherwingCliffs"] = 331293655296,
					["NetherwingLedge"] = 478350114284,
					["ShadowmoonVilliage"] = 37703123456,
					["TheBlackTemple"] = 135927431564,
					["TheDeathForge"] = 138817306880,
					["TheHandofGuldan"] = 97050427904,
					["TheWardensCage"] = 277517593088,
					["WildhammerStronghold"] = 246063488512,
				},
				["ShadowmoonValleyDR"] = {
					["ANGUISHFORTRESS"] = 171945763125,
					["DARKTIDEROOST"] = 501928371482,
					["ELODOR"] = 446966051,
					["EMBAARI"] = 169934582106,
					["GARRISON"] = 203709663,
					["GLOOMSHADE"] = 5703450853,
					["GULVAR"] = 27579652,
					["KARABOR"] = 161624684937,
					["NOGARRISON"] = 203709663,
					["SHAZGUL"] = 338500486426,
					["SHIMMERINGMOOR"] = 329040270624,
					["SOCRETHAR"] = 441709700298,
					["SWISLAND"] = 494245413037,
				},
				["SholazarBasin"] = {
					["KartaksHold"] = 402733176137,
					["RainspeakerCanopy"] = 262440987855,
					["RiversHeart"] = 364375254484,
					["TheAvalanche"] = 99409470786,
					["TheGlimmeringPillar"] = 36830518566,
					["TheLifebloodPillar"] = 144407119160,
					["TheMakersOverlook"] = 254142609641,
					["TheMakersPerch"] = 145135755513,
					["TheMosslightPillar"] = 381456540911,
					["TheSavageThicket"] = 55176303909,
					["TheStormwrightsShelf"] = 62422024460,
					["TheSuntouchedPillar"] = 199802286535,
				},
				["Silithus"] = {
					["CenarionHold"] = 153993089316,
					["HiveAshi"] = 4656999829,
					["HiveRegal"] = 333258791401,
					["HiveZora"] = 221191192094,
					["SouthwindVillage"] = 194924236085,
					["TheCrystalVale"] = 132372809,
					["TheScarabWall"] = 488552748612,
					["TwilightBaseCamp"] = 162240110002,
					["ValorsRest"] = 644117819,
				},
				["Silverpine"] = {
					["Ambermill"] = 268969430299,
					["BerensPeril"] = 435395239230,
					["DeepElemMine"] = 228139931865,
					["FenrisIsle"] = 16715659616,
					["ForsakenHighCommand"] = 466795881,
					["ForsakenRearGuard"] = 387168442,
					["NorthTidesBeachhead"] = 73353338030,
					["NorthTidesRun"] = 154494233,
					["OlsensFarthing"] = 267689041147,
					["ShadowfangKeep"] = 362204533939,
					["TheBattlefront"] = 461001380095,
					["TheDecrepitFields"] = 167997759664,
					["TheForsakenFront"] = 351567803544,
					["TheGreymaneWall"] = 543646976409,
					["TheSepulcher"] = 168935235802,
					["TheSkitteringDark"] = 247640291,
					["ValgansField"] = 83161690274,
				},
				["SouthernBarrens"] = {
					["BaelModan"] = 491117563149,
					["Battlescar"] = 329926304128,
					["ForwardCommand"] = 269952921816,
					["FrazzlecrazMotherload"] = 468433702130,
					["HonorsStand"] = 210938171,
					["HuntersHill"] = 69034232026,
					["NorthwatchHold"] = 158414953752,
					["RazorfenKraul"] = 567222087894,
					["RuinsofTaurajo"] = 307346189597,
					["TheOvergrowth"] = 125931063651,
					["VendettaPoint"] = 210733586686,
				},
				["SpiresOfArak"] = {
					["BLOODBLADEREDOUBT"] = 225836165329,
					["BLOODMANEVALLEY"] = 376239806693,
					["CENTERRAVENNEST"] = 274269927612,
					["CLUTCHPOP"] = 410728497369,
					["EASTMUSHROOMS"] = 167110758582,
					["EMPTYGARRISON"] = 280542506174,
					["HOWLINGCRAG"] = 481577342,
					["NWCORNER"] = 107266362,
					["SETHEKKHOLLOW"] = 136910773486,
					["SKETTIS"] = 303217011,
					["SOLOSPIRENORTH"] = 90644443332,
					["SOLOSPIRESOUTH"] = 296745093289,
					["SOUTHPORT"] = 352512560325,
					["VEILAKRAZ"] = 89415457020,
					["VEILZEKK"] = 288309354694,
					["VENTURECOVE"] = 510515152098,
					["WRITHINGMIRE"] = 212807668965,
				},
				["StonetalonMountains"] = {
					["BattlescarValley"] = 203168195874,
					["BoulderslideRavine"] = 550313816258,
					["CliffwalkerPost"] = 102389448945,
					["GreatwoodVale"] = 481667805506,
					["KromgarFortress"] = 366762725559,
					["Malakajin"] = 577247513811,
					["MirkfallonLake"] = 153982590196,
					["RuinsofEldrethar"] = 441692957917,
					["StonetalonPeak"] = 278122801,
					["SunRockRetreat"] = 306386794718,
					["ThaldarahOverlook"] = 130187195602,
					["TheCharredVale"] = 395345938709,
					["UnearthedGrounds"] = 396896712969,
					["WebwinderHollow"] = 431073003684,
					["WebwinderPath"] = 282885193995,
					["WindshearCrag"] = 192758971766,
					["WindshearHold"] = 310852646064,
				},
				["StranglethornJungle"] = {
					["BalAlRuins"] = 180668736671,
					["BaliaMahRuins"] = 261335758063,
					["Bambala"] = 176687333566,
					["FortLivingston"] = 403070691558,
					["GromGolBaseCamp"] = 245125794983,
					["KalAiRuins"] = 197939845259,
					["KurzensCompound"] = 523483380,
					["LakeNazferiti"] = 102438768880,
					["Mazthoril"] = 391353994590,
					["MizjahRuins"] = 264546464925,
					["MoshOggOgreMound"] = 272226269418,
					["NesingwarysExpedition"] = 67966793955,
					["RebelCamp"] = 321034542,
					["RuinsOfZulKunda"] = 165946596,
					["TheVileReef"] = 223485329644,
					["ZulGurub"] = 656982392,
					["ZuuldalaRuins"] = 23632026948,
				},
				["Sunwell"] = {
					["SunsReachHarbor"] = 270847607296,
					["SunsReachSanctum"] = 4558684672,
				},
				["SwampOfSorrows"] = {
					["Bogpaddle"] = 629343494,
					["IthariusCave"] = 259853185292,
					["MarshtideWatch"] = 501569866,
					["MistyValley"] = 85899638028,
					["MistyreedStrand"] = 629830034,
					["PoolOfTears"] = 256153720065,
					["Sorrowmurk"] = 86636923109,
					["SplinterspearJunction"] = 253606845678,
					["Stagalbog"] = 387113598299,
					["Stonard"] = 277337133413,
					["TheHarborage"] = 84994715914,
					["TheShiftingMire"] = 26117251364,
				},
				["Talador"] = {
					["ARUUNA"] = 191752284549,
					["AUCHINDOUN"] = 382606776629,
					["CENTERISLES"] = 245385945340,
					["COURTOFSOULS"] = 283625362739,
					["FORTWRYNN"] = 45691940132,
					["GORDALFORTRESS"] = 406449326503,
					["GULROK"] = 391015315734,
					["NORTHGATE"] = 598889870,
					["ORUNAICOAST"] = 448015639,
					["SEENTRANCE"] = 320693621044,
					["SHATTRATH"] = 23804099990,
					["TELMOR"] = 548899288561,
					["TOMBOFLIGHTS"] = 291353350470,
					["TUUREM"] = 159408947425,
					["ZANGARRA"] = 38328882463,
				},
				["TanaanJungle"] = {
					["DARKPORTAL"] = 146697278797,
					["DRAENEISW"] = 394148397230,
					["FANGRILA"] = 421356904791,
					["FELFORGE"] = 201200950495,
					["IRONFRONT"] = 283468092625,
					["IRONHARBOR"] = 66890012861,					
					["KILJAEDEN"] = 25107386733,
					["KRANAK"] = 100988614994,
					["LIONSWATCH"] = 336568992014,
					["MARSHLANDS"] = 411553720566,
					["SHANAAR"] = 380283185400,
					["VOLMAR"] = 184135423214,
					["ZETHGOL"] = 208429903122,
					["HELLFIRECITADEL"] = 281586943303,				
				},
				["Tanaris"] = {
					["AbyssalSands"] = 159225415935,
					["BrokenPillar"] = 226992753859,
					["CavernsofTime"] = 256082359509,
					["DunemaulCompound"] = 276271645927,
					["EastmoonRuins"] = 366544587949,
					["Gadgetzan"] = 99216445629,
					["GadgetzanBay"] = 10166293758,
					["LandsEndBeach"] = 485783462112,
					["LostRiggerCover"] = 216467229874,
					["SandsorrowWatch"] = 106607826134,
					["SouthbreakShore"] = 310769805586,
					["SouthmoonRuins"] = 375051734248,
					["TheGapingChasm"] = 391311977697,
					["TheNoxiousLair"] = 226830252211,
					["ThistleshrubValley"] = 300841997533,
					["ValleryoftheWatchers"] = 463050307853,
					["ZulFarrak"] = 193132859,
				},
				["Teldrassil"] = {
					["BanethilHollow"] = 237689351343,
					["Darnassus"] = 194503853354,
					["GalardellValley"] = 254965639346,
					["GnarlpineHold"] = 381542388934,
					["LakeAlameth"] = 333302671649,
					["PoolsofArlithrien"] = 261281237132,
					["RutheranVillage"] = 481381544253,
					["Shadowglen"] = 112173737201,
					["StarbreezeVillage"] = 233572602043,
					["TheCleft"] = 117491075216,
					["TheOracleGlade"] = 96926421186,
					["WellspringLake"] = 89521382565,
				},
				["TerokkarForest"] = {
					["AllerianStronghold"] = 297930064128,
					["AuchenaiGrounds"] = 466263189760,
					["BleedingHollowClanRuins"] = 323304668416,
					["BonechewerRuins"] = 295825572096,
					["CarrionHill"] = 292453351680,
					["CenarionThicket"] = 329515264,
					["FirewingPoint"] = 160635027841,
					["GrangolvarVilliage"] = 183760060928,
					["RaastokGlade"] = 165886034176,
					["RazorthornShelf"] = 20902576384,
					["RefugeCaravan"] = 288094421120,
					["RingofObservance"] = 370766250240,
					["SethekkTomb"] = 310568550656,
					["ShattrathCity"] = 4404544000,
					["SkethylMountains"] = 374133293568,
					["SmolderingCaravan"] = 494258045184,
					["StonebreakerHold"] = 177583948032,
					["TheBarrierHills"] = 4416864512,
					["Tuurem"] = 36984848640,
					["VeilRhaze"] = 388927586560,
					["WrithingMound"] = 351551095040,
				},
				["TheCapeOfStranglethorn"] = {
					["BootyBay"] = 366449261793,
					["CrystalveinMine"] = 78937010447,
					["GurubashiArena"] = 362025198,
					["HardwrenchHideaway"] = 124772382052,
					["JagueroIsle"] = 434285846768,
					["MistvaleValley"] = 266716039421,
					["NekmaniWellspring"] = 229013419254,
					["RuinsofAboraz"] = 194906341560,
					["RuinsofJubuwal"] = 128266237083,
					["TheSundering"] = 474170612,
					["WildShore"] = 421263593708,
				},
				["TheHiddenPass"] = {
					["TheBlackMarket"] = 188294346207,
					["TheHiddenCliffs"] = 454258982,
					["TheHiddenSteps"] = 512607059234,
				},
				["TheJadeForest"] = {
					["ChunTianMonastery"] = 60444317923,
					["DawnsBlossom"] = 191467047146,
					["DreamersPavillion"] = 558842925274,
					["EmperorsOmen"] = 22999675082,
					["GlassfinVillage"] = 384950393110,
					["GrookinMound"] = 229971825917,
					["HellscreamsHope"] = 80720599236,
					["JadeMines"] = 157185882348,
					["NectarbreezeOrchard"] = 354639151323,
					["NookaNooka"] = 162333406427,
					["RuinsOfGanShi"] = 331512004,
					["SerpentsSpine"] = 321455874239,
					["SlingtailPits"] = 447125573811,
					["TempleOfTheJadeSerpent"] = 317244787976,
					["TheArboretum"] = 231359072498,
					["Waywardlanding"] = 517906557147,
					["WindlessIsle"] = 46736437499,
					["WreckOfTheSkyShark"] = 211974354,
				},
				["TheLostIsles"] = {
					["Alliancebeachhead"] = 373797597361,
					["BilgewaterLumberyard"] = 46655554808,
					["GallywixDocks"] = 22916812973,
					["HordeBaseCamp"] = 492029802718,
					["KTCOilPlatform"] = 12265339036,
					["Lostpeak"] = 23158330718,
					["OoomlotVillage"] = 370973822173,
					["Oostan"] = 173388597458,
					["RaptorRise"] = 395573408936,
					["RuinsOfVashelan"] = 485792899284,
					["ScorchedGully"] = 198981222705,
					["ShipwreckShore"] = 438285024428,
					["SkyFalls"] = 141096577214,
					["TheSavageGlen"] = 349189660903,
					["TheSlavePits"] = 73307194580,
					["WarchiefsLookout"] = 154895882399,
					["landingSite"] = 385868764302,
				},
				["TheStormPeaks"] = {
					["BorsBreath"] = 402767678786,
					["BrunnhildarVillage"] = 397640247601,
					["DunNiffelem"] = 306521177397,
					["EngineoftheMakers"] = 318159113426,
					["Frosthold"] = 460775977204,
					["GarmsBane"] = 505073040568,
					["NarvirsCradle"] = 154843462836,
					["Nidavelir"] = 221304266973,
					["SnowdriftPlains"] = 153715187917,
					["SparksocketMinefield"] = 502765134075,
					["TempleofLife"] = 121930791094,
					["TempleofStorms"] = 323447066793,
					["TerraceoftheMakers"] = 131303036267,
					["Thunderfall"] = 192857739570,
					["Ulduar"] = 228861297,
					["Valkyrion"] = 341552822500,
				},
				["TheWanderingIsle"] = {
					["Fe-FangVillage"] = 9804478698,
					["MandoriVillage"] = 316091521634,
					["MorningBreezeVillage"] = 38867889413,
					["Pei-WuForest"] = 436307499659,
					["PoolofthePaw"] = 348203970780,
					["RidgeofLaughingWinds"] = 212793099577,
					["SkyfireCrash-Site"] = 434995731802,
					["TempleofFiveDawns"] = 195835672159,
					["TheDawningValley"] = 341471909,
					["TheRows"] = 317282702721,
					["TheSingingPools"] = 13456862580,
					["TheWoodofStaves"] = 216909958109,
				},
				["ThousandNeedles"] = {
					["DarkcloudPinnacle"] = 124731519293,
					["FreewindPost"] = 200005664180,
					["Highperch"] = 143881793782,
					["RazorfenDowns"] = 312797545,
					["RustmaulDiveSite"] = 499842755818,
					["SouthseaHoldfast"] = 443174617334,
					["SplithoofHeights"] = 53212506543,
					["TheGreatLift"] = 142844176,
					["TheShimmeringDeep"] = 276571778459,
					["TheTwilightWithering"] = 353625263478,
					["TwilightBulwark"] = 258903279974,
					["WestreachSummit"] = 333080,
				},
				["Tirisfal"] = {
					["AgamandMills"] = 96976769309,
					["BalnirFarmstead"] = 348515388658,
					["BrightwaterLake"] = 131597635794,
					["Brill"] = 271086442695,
					["CalstonEstate"] = 274212234419,
					["ColdHearthManor"] = 340814644436,
					["CrusaderOutpost"] = 249827641519,
					["Deathknell"] = 222274411951,
					["GarrensHaunt"] = 139013085374,
					["NightmareVale"] = 349330236641,
					["RuinsofLorderon"] = 385917136262,
					["ScarletMonastery"] = 51242080518,
					["ScarletWatchPost"] = 107026294945,
					["SollidenFarmstead"] = 206369424670,
					["TheBulwark"] = 355078588709,
					["VenomwebVale"] = 161850088698,
				},
				["TolBarad"] = {
				},
				["TolBaradDailyArea"] = {
				},
				["TownlongWastes"] = {
					["GaoRanBlockade"] = 503083901281,
					["KriVess"] = 224852718847,
					["MingChiCrossroads"] = 480400078071,
					["NiuzaoTemple"] = 258995494184,
					["OsulMesa"] = 199229743342,
					["ShadoPanGarrison"] = 413823838421,
					["ShanzeDao"] = 131324204,
					["Sikvess"] = 465251314949,
					["SriVess"] = 206255189286,
					["TheSumprushes"] = 396782417167,
					["palewindVillage"] = 389420468506,
				},
				["TwilightHighlands"] = {
					["Bloodgulch"] = 220553442519,
					["CrucibleOfCarnage"] = 288168820939,
					["Crushblow"] = 480350768310,
					["DragonmawPass"] = 128928921883,
					["DragonmawPort"] = 263728610555,
					["DunwaldRuins"] = 394477660357,
					["FirebeardsPatrol"] = 285065008343,
					["GlopgutsHollow"] = 95868352686,
					["GorshakWarCamp"] = 236792752322,
					["GrimBatol"] = 239531741414,
					["Highbank"] = 433449045212,
					["HighlandForest"] = 354840453359,
					["HumboldtConflaguration"] = 95923877007,
					["Kirthaven"] = 505687348,
					["ObsidianForest"] = 408479367510,
					["RuinsOfDrakgor"] = 310565070,
					["SlitheringCove"] = 182114788550,
					["TheBlackBreach"] = 130445166803,
					["TheGullet"] = 192482037935,
					["TheKrazzworks"] = 686006498,
					["TheTwilightBreach"] = 206485803207,
					["TheTwilightCitadel"] = 337313630569,
					["TheTwilightGate"] = 382595177637,
					["Thundermar"] = 100250391790,
					["TwilightShore"] = 371080767748,
					["VermillionRedoubt"] = 17254588740,
					["VictoryPoint"] = 328881831089,
					["WeepingWound"] = 375584982,
					["WyrmsBend"] = 249323264191,
				},
				["Uldum"] = {
					["AkhenetFields"] = 297920554148,
					["CradelOfTheAncient"] = 432001950922,
					["HallsOfOrigination"] = 198196840717,
					["KhartutsTomb"] = 568548555,
					["LostCityOfTheTolVir"] = 313011799273,
					["Marat"] = 187256997024,
					["Nahom"] = 174557694189,
					["Neferset"] = 412743891153,
					["ObeliskOfTheMoon"] = 115573136,
					["ObeliskOfTheStars"] = 130500700356,
					["ObeliskOfTheSun"] = 303151918349,
					["Orsis"] = 146305961209,
					["Ramkahen"] = 72371899620,
					["RuinsOfAhmtul"] = 382907670,
					["RuinsOfAmmon"] = 310539183307,
					["Schnottzslanding"] = 237326599480,
					["TahretGrounds"] = 207803808918,
					["TempleofUldum"] = 136503837992,
					["TheCursedlanding"] = 183324963053,
					["TheGateofUnendingCycles"] = 16784797857,
					["TheTrailOfDevestation"] = 375425020110,
					["TheVortexPinnacle"] = 508567948501,
					["ThroneOfTheFourWinds"] = 465170568462,
					["VirnaalDam"] = 231356907671,
				},
				["UngoroCrater"] = {
					["FirePlumeRidge"] = 206532018497,
					["FungalRock"] = 584252640,
					["GolakkaHotSprings"] = 242817979701,
					["IronstonePlateau"] = 216562628805,
					["LakkariTarPits"] = 320117168,
					["MarshalsStand"] = 354819418316,
					["MossyPile"] = 192543909050,
					["TerrorRun"] = 383496000828,
					["TheMarshlands"] = 275479163143,
					["TheRollingGarden"] = 42468705617,
					["TheScreamingReaches"] = 164966732,
					["TheSlitheringScar"] = 412668414333,
				},
				["ValeofEternalBlossoms"] = {
					["GuoLaiRuins"] = 3312809297,
					["MistfallVillage"] = 389978309942,
					["MoguShanPalace"] = 24282269045,
					["SettingSunTraining"] = 251256026462,
					["TheGoldenStair"] = 17524062450,
					["TheStairsAscent"] = 287272443326,
					["TheTwinMonoliths"] = 104619059472,
					["TuShenBurialGround"] = 339668685067,
					["WhiteMoonShrine"] = 11243100458,
					["WhitepetalLake"] = 182827902219,
					["WinterboughGlade"] = 114894910825,
				},
				["ValleyoftheFourWinds"] = {
					["CliffsofDispair"] = 434017411582,
					["DustbackGorge"] = 368293761233,
					["GildedFan"] = 44482990288,
					["GrandGranery"] = 349316534586,
					["Halfhill"] = 190511830222,
					["HarvestHome"] = 256629796100,
					["KuzenVillage"] = 79692087495,
					["MudmugsPlace"] = 173460907238,
					["NesingwarySafari"] = 350149236985,
					["PaoquanHollow"] = 112755726609,
					["PoolsofPurity"] = 62815197397,
					["RumblingTerrace"] = 323806811413,
					["SilkenFields"] = 272212692222,
					["SingingMarshes"] = 139764993199,
					["StormsoutBrewery"] = 408260215041,
					["Theheartland"] = 80796328222,
					["ThunderfootFields"] = 652539260,
					["ZhusDecent"] = 123139853615,
				},
				["VashjirDepths"] = {
					["AbandonedReef"] = 282446932339,
					["AbyssalBreach"] = 521624043,
					["ColdlightChasm"] = 300927015179,
					["DeepfinRidge"] = 34648365419,
					["FireplumeTrench"] = 118442159402,
					["KorthunsEnd"] = 304301344114,
					["LGhorek"] = 225655952690,
					["Seabrush"] = 196930169057,
				},
				["VashjirKelpForest"] = {
					["DarkwhisperGorge"] = 245366977756,
					["GnawsBoneyard"] = 349439223095,
					["GubogglesLedge"] = 301066304739,
					["HoldingPens"] = 431048895804,
					["HonorsTomb"] = 46569568547,
					["LegionsFate"] = 37801487638,
					["TheAccursedReef"] = 174329136468,
				},
				["VashjirRuins"] = {
					["BethMoraRidge"] = 478242110799,
					["GlimmeringdeepGorge"] = 238653985040,
					["Nespirah"] = 280729236766,
					["RuinsOfTherseral"] = 188485958853,
					["RuinsOfVashjir"] = 287990719837,
					["ShimmeringGrotto"] = 419715411,
					["SilverTideHollow"] = 34517351904,
				},
				["WesternPlaguelands"] = {
					["Andorhal"] = 368394442192,
					["CaerDarrow"] = 419389718722,
					["DalsonsFarm"] = 249422872901,
					["DarrowmereLake"] = 380639701484,
					["FelstoneField"] = 245053477105,
					["GahrronsWithering"] = 229226311921,
					["Hearthglen"] = 246693296,
					["NorthridgeLumberCamp"] = 132312652135,
					["RedpineDell"] = 226859554082,
					["SorrowHill"] = 481310241136,
					["TheBulwark"] = 252379984188,
					["TheWeepingCave"] = 162713016505,
					["TheWrithingHaunt"] = 356977413289,
					["ThondrorilRiver"] = 559337783,
				},
				["Westfall"] = {
					["AlexstonFarmstead"] = 282569439578,
					["DemontsPlace"] = 403939986633,
					["FurlbrowsPumpkinFarm"] = 413357253,
					["GoldCoastQuarry"] = 85034584299,
					["JangoloadMine"] = 326341828,
					["Moonbrook"] = 349289272552,
					["SaldeansFarm"] = 87446238452,
					["SentinelHill"] = 243089548517,
					["TheDaggerHills"] = 424446018852,
					["TheDeadAcre"] = 215305438401,
					["TheDustPlains"] = 406377993533,
					["TheGapingChasm"] = 180697130168,
					["TheJansenStead"] = 497208522,
					["TheMolsenFarm"] = 127066669258,
					["WestfallLighthouse"] = 512406756563,
				},
				["Wetlands"] = {
					["AngerfangEncampment"] = 216198807788,
					["BlackChannelMarsh"] = 257737072941,
					["BluegillMarsh"] = 109554426177,
					["DireforgeHills"] = 37038035273,
					["DunAlgaz"] = 450260852010,
					["DunModr"] = 7889675521,
					["GreenwardensGrove"] = 110004286714,
					["IronbeardsTomb"] = 81994678457,
					["MenethilHarbor"] = 318901693765,
					["MosshideFen"] = 249638923633,
					["RaptorRidge"] = 132698592512,
					["Satlspray"] = 228878586,
					["SlabchiselsSurvey"] = 378515288364,
					["SundownMarsh"] = 67772861716,
					["ThelganRock"] = 360092744962,
					["WhelgarsExcavationSite"] = 209574100266,
				},
				["Winterspring"] = {
					["Everlook"] = 209885304002,
					["FrostfireHotSprings"] = 126799349112,
					["FrostsaberRock"] = 319041868,
					["FrostwhisperGorge"] = 509398408509,
					["IceThistleHills"] = 337764377849,
					["LakeKeltheril"] = 288153143567,
					["Mazthoril"] = 365490845953,
					["OwlWingThicket"] = 471955822846,
					["StarfallVillage"] = 35673952623,
					["TheHiddenGrove"] = 18778160461,
					["TimbermawPost"] = 324366758250,
					["WinterfallVillage"] = 194964047069,
				},
				["Zangarmarsh"] = {
					["AngoroshGrounds"] = 53779628288,
					["AngoroshStronghold"] = 130154752,
					["BloodscaleEnclave"] = 443006845184,
					["CenarionRefuge"] = 345399099700,
					["CoilfangReservoir"] = 97121730816,
					["FeralfenVillage"] = 356811883008,
					["MarshlightLake"] = 163293954304,
					["OreborHarborage"] = 27189051648,
					["QuaggRidge"] = 349114293504,
					["Sporeggar"] = 216917082624,
					["Telredor"] = 120856248576,
					["TheDeadMire"] = 138190258462,
					["TheHewnBog"] = 54990995712,
					["TheLagoon"] = 325880905984,
					["TheSpawningGlen"] = 364031246592,
					["TwinspireRuins"] = 267720589568,
					["UmbrafenVillage"] = 495750167808,
					["ZabraJin"] = 249291866368,
				},
				["ZulDrak"] = {
					["AltarOfHarKoa"] = 371000083721,
					["AltarOfMamToth"] = 95092536631,
					["AltarOfQuetzLun"] = 270145978629,
					["AltarOfRhunok"] = 136817459447,
					["AltarOfSseratus"] = 180690870509,
					["AmphitheaterOfAnguish"] = 308467202314,
					["DrakSotraFields"] = 384741680414,
					["GunDrak"] = 659858768,
					["Kolramas"] = 469623872814,
					["LightsBreach"] = 389958387009,
					["ThrymsEnd"] = 265214505232,
					["Voltarus"] = 205267438810,
					["Zeramas"] = 442389233971,
					["ZimTorga"] = 259274311929,
				},
				["AszunaDungeonExterior"] = {
					["EYEOFAZSHARA"] = 41579344,
				},
				["Azsuna"] = {
					["FARONAAR"] = 217070183754,
					["FELBLAZE"] = 623164655,
					["GREENWAY"] = 102477521143,
					["ISLEOFTHEWATCHERS"] = 430865395009,
					["LLOTHIENHIGHLANDS"] = 74318075231,
					["LOSTORCHARD"] = 269673787,
					["NARTHALAS"] = 186219954448,
					["OCEANUSCOVE"] = 262408513742,
					["RUINEDSANCTUM"] = 250730545372,
					["TEMPLELIGHTS"] = 365576834229,
					["ZARKHENAR"] = 500370720,
				},
				["BrokenShore"] = {
					["BROKENVALLEY"] = 90460981586,
					["DEADWOODLANDING"] = 279403812022,
					["DELIVERANCEPOINT"] = 324597508483,
					["FELRAGESTRAND"] = 107999416652,
					["SOULRUIN"] = 193681701202,
					["THELOSTTEMPLE"] = 182125318452,
					["THEWEEPINGTERRACE"] = 14325863700,
					["TOMBOFSARGERAS"] = 524596536,
				},		
				["Highmountain"] = {
					["BLOODHUNTHIGHLANDS"] = 80852805929,
					["CAVEA"] = 204477663342,
					["FELTOTEM"] = 33466685696,
					["FROSTHOOFWATCH"] = 438496875706,
					["IRONHORNENCLAVE"] = 440708368672,
					["NIGHTWATCHERSPERCH"] = 261993307480,
					["PINEROCKBASIN"] = 267700555993,
					["RIVERBEND"] = 386876625110,
					["ROCKAWAYSHALLOWS"] = 48810473679,
					["SHIPWRECKCOVE"] = 347253019,
					["SKYHORN"] = 192574362935,
					["STONEHOOFWATCH"] = 253921403221,
					["SYLVANFALLS"] = 367220038077,
					["THUNDERTOTEM"] = 324618362100,
					["TRUESHOTLODGE"] = 253664374956,
				},			
				["Niskara"] = {
					["DEATHKNIGHT"] = 255834839156,
					["MARKSMAN"] = 250464104710,
				},	
				["Stormheim"] = {
					["AGGRAMMARSVAULT"] = 225864508615,
					["BLACKBEAKOVERLOOK"] = 138674391337,
					["DREADWAKE"] = 442861083863,
					["DREYRGROT"] = 286337942660,
					["GREYWATCH"] = 364678122669,
					["HALLSOFVALOR"] = 400045662460,
					["HAUSTVALD"] = 201431627976,
					["HRYDSHAL"] = 379031187063,
					["MAWOFNASHAL"] = 18083325,
					["MORHEIM"] = 336858370198,
					["NASTRONDIR"] = 102367430897,
					["QATCHMANSROCK"] = 87626516615,
					["RUNEWOOD"] = 243286628546,
					["SHIELDSREST"] = 722645281,
					["SKOLDASHIL"] = 370971681969,
					["STORMSREACH"] = 127236473012,
					["TALONREST"] = 303126757667,
					["TIDESKORNHARBOR"] = 196997225677,
					["VALDISDALL"] = 309785163962,
					["WEEPINGBLUFFS"] = 198701279618,
				},		
				["Suramar"] = {
					["AMBERVALE"] = 192338517214,
					["CRIMSONTHICKET"] = 516289863,
					["FALANAAR"] = 146053330168,
					["FELSOULHOLD"] = 327683517729,
					["GRANDPROMENADE"] = 306377428323,
					["JANDVIK"] = 611871139,
					["MOONGUARDSTRONGHOLD"] = 61068768,
					["MOONWHISPERGULCH"] = 211087788,
					["RUINSOFELUNEETH"] = 242942705885,
					["SURAMARCITY"] = 355817833942,
					["TELANOR"] = 343265667,
				},
				["Valsharah"] = {
					["ANDUTALAH"] = 269051216113,
					["BLACKROOKHOLD"] = 188179805434,
					["BRADENSBROOK"] = 295550832951,
					["DREAMGROVE"] = 297120038,
					["GLOAMINGREEF"] = 294348174575,
					["GROVEOFCENARIUS"] = 377362733227,
					["LORLATHIL"] = 443945218225,
					["MISTVALE"] = 19967336722,
					["MOONCLAWVALE"] = 408597849342,
					["SHALANIR"] = 439722310,
					["SMOLDERHIDE"] = 515736006997,
					["TEMPLEOFELUNE"] = 258179558616,
					["THASTALAH"] = 447035384026,
				},		
				["ArgusCore"] = {
					["DEFILEDPATH"] = 307627634,
					["FELFIREARMORY"] = 684692,
					["TERMINUS"] = 256111983059,
				},
				["ArgusMacAree"] = {
					["CONSERVATORY"] = 119707895097,
					["RUINSOFORONAAR"] = 305234499849,
					["SEATOFTRIUMVIRATE"] = 58260463055,
					["SHADOWGUARD"] = 472562,
					["TRIUMVIRATES"] = 403083370780,
					["UPPERTERRACE"] = 331453,
				},
				["ArgusSurface"] = {
					["ANNIHILANPITS"] = 191515410728,
					["KROKULHOVEL"] = 391291126067,
					["NATHRAXAS"] = 175545155,
					["PETRIFIEDFOREST"] = 310895832509,
					["SHATTEREDFIELDS"] = 148215712242,
				},						
				['*'] = {},
				
				
				
				----------- Content of DataExport: ----------------
				[863] = {
					{
						["offsetX"] = 620,
						["textureHeight"] = 1249,
						["textureWidth"] = 1225,
						["offsetY"] = 565,
						["fileDataIDs"] = {
							2024017, -- [1]
							2024028, -- [2]
							2024035, -- [3]
							2024036, -- [4]
							2024037, -- [5]
							2024038, -- [6]
							2024039, -- [7]
							2024040, -- [8]
							2024041, -- [9]
							2024018, -- [10]
							2024019, -- [11]
							2024020, -- [12]
							2024021, -- [13]
							2024022, -- [14]
							2024023, -- [15]
							2024024, -- [16]
							2024025, -- [17]
							2024026, -- [18]
							2024027, -- [19]
							2024029, -- [20]
							2024030, -- [21]
							2024031, -- [22]
							2024032, -- [23]
							2024033, -- [24]
							2024034, -- [25]
						},
					}, -- [1]
					{
						["offsetX"] = 1072,
						["textureHeight"] = 809,
						["textureWidth"] = 1289,
						["offsetY"] = 1676,
						["fileDataIDs"] = {
							2023943, -- [1]
							2023954, -- [2]
							2023960, -- [3]
							2023961, -- [4]
							2023962, -- [5]
							2023963, -- [6]
							2023964, -- [7]
							2023965, -- [8]
							2023966, -- [9]
							2023944, -- [10]
							2023945, -- [11]
							2023946, -- [12]
							2023947, -- [13]
							2023948, -- [14]
							2023949, -- [15]
							2023950, -- [16]
							2023951, -- [17]
							2023952, -- [18]
							2023953, -- [19]
							2023955, -- [20]
							2023956, -- [21]
							2023957, -- [22]
							2023958, -- [23]
							2023959, -- [24]
						},
					}, -- [2]
					{
						["offsetX"] = 484,
						["textureHeight"] = 967,
						["textureWidth"] = 1157,
						["offsetY"] = 1539,
						["fileDataIDs"] = {
							2023923, -- [1]
							2023934, -- [2]
							2023936, -- [3]
							2023937, -- [4]
							2023938, -- [5]
							2023939, -- [6]
							2023940, -- [7]
							2023941, -- [8]
							2023942, -- [9]
							2023924, -- [10]
							2023925, -- [11]
							2023926, -- [12]
							2023927, -- [13]
							2023928, -- [14]
							2023929, -- [15]
							2023930, -- [16]
							2023931, -- [17]
							2023932, -- [18]
							2023933, -- [19]
							2023935, -- [20]
						},
					}, -- [3]
					{
						["offsetX"] = 1511,
						["textureHeight"] = 991,
						["textureWidth"] = 800,
						["offsetY"] = 1043,
						["fileDataIDs"] = {
							2023713, -- [1]
							2023721, -- [2]
							2023722, -- [3]
							2023723, -- [4]
							2023724, -- [5]
							2023725, -- [6]
							2023726, -- [7]
							2023727, -- [8]
							2023728, -- [9]
							2023714, -- [10]
							2023715, -- [11]
							2023716, -- [12]
							2023717, -- [13]
							2023718, -- [14]
							2023719, -- [15]
							2023720, -- [16]
						},
					}, -- [4]
				},
				[862] = {
					{
						["offsetX"] = 2409,
						["textureHeight"] = 912,
						["textureWidth"] = 979,
						["offsetY"] = 0,
						["fileDataIDs"] = {
							2034400, -- [1]
							2034408, -- [2]
							2034409, -- [3]
							2034410, -- [4]
							2034411, -- [5]
							2034412, -- [6]
							2034413, -- [7]
							2034414, -- [8]
							2034415, -- [9]
							2034401, -- [10]
							2034402, -- [11]
							2034403, -- [12]
							2034404, -- [13]
							2034405, -- [14]
							2034406, -- [15]
							2034407, -- [16]
						},
					}, -- [1]
					{
						["offsetX"] = 1046,
						["textureHeight"] = 1287,
						["textureWidth"] = 1243,
						["offsetY"] = 1273,
						["fileDataIDs"] = {
							2034370, -- [1]
							2034381, -- [2]
							2034392, -- [3]
							2034394, -- [4]
							2034395, -- [5]
							2034396, -- [6]
							2034397, -- [7]
							2034398, -- [8]
							2034399, -- [9]
							2034371, -- [10]
							2034372, -- [11]
							2034373, -- [12]
							2034374, -- [13]
							2034375, -- [14]
							2034376, -- [15]
							2034377, -- [16]
							2034378, -- [17]
							2034379, -- [18]
							2034380, -- [19]
							2034382, -- [20]
							2034383, -- [21]
							2034384, -- [22]
							2034385, -- [23]
							2034386, -- [24]
							2034387, -- [25]
							2034388, -- [26]
							2034389, -- [27]
							2034390, -- [28]
							2034391, -- [29]
							2034393, -- [30]
						},
					}, -- [2]
					{
						["offsetX"] = 2631,
						["textureHeight"] = 617,
						["textureWidth"] = 726,
						["offsetY"] = 1023,
						["fileDataIDs"] = {
							2034361, -- [1]
							2034362, -- [2]
							2034363, -- [3]
							2034364, -- [4]
							2034365, -- [5]
							2034366, -- [6]
							2034367, -- [7]
							2034368, -- [8]
							2034369, -- [9]
						},
					}, -- [3]
					{
						["offsetX"] = 1825,
						["textureHeight"] = 1344,
						["textureWidth"] = 999,
						["offsetY"] = 1216,
						["fileDataIDs"] = {
							2034337, -- [1]
							2034348, -- [2]
							2034354, -- [3]
							2034355, -- [4]
							2034356, -- [5]
							2034357, -- [6]
							2034358, -- [7]
							2034359, -- [8]
							2034360, -- [9]
							2034338, -- [10]
							2034339, -- [11]
							2034340, -- [12]
							2034341, -- [13]
							2034342, -- [14]
							2034343, -- [15]
							2034344, -- [16]
							2034345, -- [17]
							2034346, -- [18]
							2034347, -- [19]
							2034349, -- [20]
							2034350, -- [21]
							2034351, -- [22]
							2034352, -- [23]
							2034353, -- [24]
						},
					}, -- [4]
					{
						["offsetX"] = 2107,
						["textureHeight"] = 967,
						["textureWidth"] = 769,
						["offsetY"] = 327,
						["fileDataIDs"] = {
							2034321, -- [1]
							2034329, -- [2]
							2034330, -- [3]
							2034331, -- [4]
							2034332, -- [5]
							2034333, -- [6]
							2034334, -- [7]
							2034335, -- [8]
							2034336, -- [9]
							2034322, -- [10]
							2034323, -- [11]
							2034324, -- [12]
							2034325, -- [13]
							2034326, -- [14]
							2034327, -- [15]
							2034328, -- [16]
						},
					}, -- [5]
					{
						["offsetX"] = 2144,
						["textureHeight"] = 1559,
						["textureWidth"] = 943,
						["offsetY"] = 0,
						["fileDataIDs"] = {
							2034293, -- [1]
							2034304, -- [2]
							2034314, -- [3]
							2034315, -- [4]
							2034316, -- [5]
							2034317, -- [6]
							2034318, -- [7]
							2034319, -- [8]
							2034320, -- [9]
							2034294, -- [10]
							2034295, -- [11]
							2034296, -- [12]
							2034297, -- [13]
							2034298, -- [14]
							2034299, -- [15]
							2034300, -- [16]
							2034301, -- [17]
							2034302, -- [18]
							2034303, -- [19]
							2034305, -- [20]
							2034306, -- [21]
							2034307, -- [22]
							2034308, -- [23]
							2034309, -- [24]
							2034310, -- [25]
							2034311, -- [26]
							2034312, -- [27]
							2034313, -- [28]
						},
					}, -- [6]
					{
						["offsetX"] = 1312,
						["textureHeight"] = 1512,
						["textureWidth"] = 888,
						["offsetY"] = 82,
						["fileDataIDs"] = {
							2034269, -- [1]
							2034280, -- [2]
							2034286, -- [3]
							2034287, -- [4]
							2034288, -- [5]
							2034289, -- [6]
							2034290, -- [7]
							2034291, -- [8]
							2034292, -- [9]
							2034270, -- [10]
							2034271, -- [11]
							2034272, -- [12]
							2034273, -- [13]
							2034274, -- [14]
							2034275, -- [15]
							2034276, -- [16]
							2034277, -- [17]
							2034278, -- [18]
							2034279, -- [19]
							2034281, -- [20]
							2034282, -- [21]
							2034283, -- [22]
							2034284, -- [23]
							2034285, -- [24]
						},
					}, -- [7]
					{
						["offsetX"] = 2325,
						["textureHeight"] = 830,
						["textureWidth"] = 934,
						["offsetY"] = 1270,
						["fileDataIDs"] = {
							2034253, -- [1]
							2034261, -- [2]
							2034262, -- [3]
							2034263, -- [4]
							2034264, -- [5]
							2034265, -- [6]
							2034266, -- [7]
							2034267, -- [8]
							2034268, -- [9]
							2034254, -- [10]
							2034255, -- [11]
							2034256, -- [12]
							2034257, -- [13]
							2034258, -- [14]
							2034259, -- [15]
							2034260, -- [16]
						},
					}, -- [8]
					{
						["offsetX"] = 1815,
						["textureHeight"] = 1207,
						["textureWidth"] = 699,
						["offsetY"] = 260,
						["fileDataIDs"] = {
							2034238, -- [1]
							2034245, -- [2]
							2034246, -- [3]
							2034247, -- [4]
							2034248, -- [5]
							2034249, -- [6]
							2034250, -- [7]
							2034251, -- [8]
							2034252, -- [9]
							2034239, -- [10]
							2034240, -- [11]
							2034241, -- [12]
							2034242, -- [13]
							2034243, -- [14]
							2034244, -- [15]
						},
					}, -- [9]
					{
						["offsetX"] = 1357,
						["textureHeight"] = 672,
						["textureWidth"] = 1130,
						["offsetY"] = 0,
						["fileDataIDs"] = {
							2034223, -- [1]
							2034230, -- [2]
							2034231, -- [3]
							2034232, -- [4]
							2034233, -- [5]
							2034234, -- [6]
							2034235, -- [7]
							2034236, -- [8]
							2034237, -- [9]
							2034224, -- [10]
							2034225, -- [11]
							2034226, -- [12]
							2034227, -- [13]
							2034228, -- [14]
							2034229, -- [15]
						},
					}, -- [10]
					{
						["offsetX"] = 2685,
						["textureHeight"] = 668,
						["textureWidth"] = 793,
						["offsetY"] = 633,
						["fileDataIDs"] = {
							2034211, -- [1]
							2034215, -- [2]
							2034216, -- [3]
							2034217, -- [4]
							2034218, -- [5]
							2034219, -- [6]
							2034220, -- [7]
							2034221, -- [8]
							2034222, -- [9]
							2034212, -- [10]
							2034213, -- [11]
							2034214, -- [12]
						},
					}, -- [11]
					{
						["offsetX"] = 321,
						["textureHeight"] = 1565,
						["textureWidth"] = 1650,
						["offsetY"] = 378,
						["fileDataIDs"] = {
							2034162, -- [1]
							2034173, -- [2]
							2034184, -- [3]
							2034195, -- [4]
							2034206, -- [5]
							2034207, -- [6]
							2034208, -- [7]
							2034209, -- [8]
							2034210, -- [9]
							2034163, -- [10]
							2034164, -- [11]
							2034165, -- [12]
							2034166, -- [13]
							2034167, -- [14]
							2034168, -- [15]
							2034169, -- [16]
							2034170, -- [17]
							2034171, -- [18]
							2034172, -- [19]
							2034174, -- [20]
							2034175, -- [21]
							2034176, -- [22]
							2034177, -- [23]
							2034178, -- [24]
							2034179, -- [25]
							2034180, -- [26]
							2034181, -- [27]
							2034182, -- [28]
							2034183, -- [29]
							2034185, -- [30]
							2034186, -- [31]
							2034187, -- [32]
							2034188, -- [33]
							2034189, -- [34]
							2034190, -- [35]
							2034191, -- [36]
							2034192, -- [37]
							2034193, -- [38]
							2034194, -- [39]
							2034196, -- [40]
							2034197, -- [41]
							2034198, -- [42]
							2034199, -- [43]
							2034200, -- [44]
							2034201, -- [45]
							2034202, -- [46]
							2034203, -- [47]
							2034204, -- [48]
							2034205, -- [49]
						},
					}, -- [12]
				},
				[895] = {
					{
						["offsetX"] = 2451,
						["textureHeight"] = 944,
						["textureWidth"] = 1242,
						["offsetY"] = 1035,
						["fileDataIDs"] = {
							2033605, -- [1]
							2033616, -- [2]
							2033618, -- [3]
							2033619, -- [4]
							2033620, -- [5]
							2033621, -- [6]
							2033622, -- [7]
							2033623, -- [8]
							2033624, -- [9]
							2033606, -- [10]
							2033607, -- [11]
							2033608, -- [12]
							2033609, -- [13]
							2033610, -- [14]
							2033611, -- [15]
							2033612, -- [16]
							2033613, -- [17]
							2033614, -- [18]
							2033615, -- [19]
							2033617, -- [20]
						},
					}, -- [1]
				},
				---------------------------
				
			}

		}
	}

	defaults.global.overlayData.Hyjal_terrain1 = defaults.global.overlayData.Hyjal
	defaults.global.overlayData.Uldum_terrain1 = defaults.global.overlayData.Uldum
	defaults.global.overlayData.Gilneas_terrain1 = defaults.global.overlayData.Gilneas
	defaults.global.overlayData.Gilneas_terrain2 = defaults.global.overlayData.Gilneas
	defaults.global.overlayData.TheLostIsles_terrain1 = defaults.global.overlayData.TheLostIsles
	defaults.global.overlayData.TheLostIsles_terrain2 = defaults.global.overlayData.TheLostIsles
	defaults.global.overlayData.TwilightHighlands_terrain1 = defaults.global.overlayData.TwilightHighlands
	defaults.global.overlayData.BlastedLands_terrain1 = defaults.global.overlayData.BlastedLands	

	local function FindTilesFrame()
		local allMapFrames = {WorldMapFrame.ScrollContainer.Child:GetChildren()}
		for i = 1, #allMapFrames do
			local frame = allMapFrames[i]
			if frame.detailTilePool then
				return frame 
			end
		end
	end
	local db
	
	C_MapExplorationInfo.GetExploredMapTextures_org = C_MapExplorationInfo.GetExploredMapTextures
	
	C_MapExplorationInfo.GetExploredMapTextures = function(mapId)
		local result = C_MapExplorationInfo.GetExploredMapTextures_org(mapId)
		
		if not DugisGuideViewer:UserSetting(DGV_REMOVEMAPFOG) 
		or DugisGuideViewer.mapsterloaded 
		or not MOD.GuideOn 
		or not DugisGuideViewer:IsBigMap(mapId) --for old maps we don't make any changes as we have stored old overrides
		then
			return result
		end
		
		result = result or {}
		
		if db and db.global.overlayData then
			if db.global.overlayData[mapId] then
				local internalOverlayData = db.global.overlayData[mapId]
				for i=1, #internalOverlayData do
					if not result[i] then
						result[i] = internalOverlayData[i]
									
						result[i]["hitRect"] = {
							["top"] = 0,
							["right"] = 0,
							["left"] = 0,
							["bottom"] = 0,
						}
						result[i]["isShownByMouseOver"] = false
					end
				end
			end
		end
		
		return result
	end
	
	--[[Returns:
		{
			mapDirectory = "",
			texData = {
				[mapName1] = 09812341,
				[mapName2] = 98745632
			}
		}
	]]
	local function GetCurrentMapOverlayData(mapId)
		local result = {texData = {}}
        
        if not mapId then
            return result
        end
		
		--For new maps we use another mechanism - overriden GetExploredMapTextures function
		if DugisGuideViewer:IsBigMap(mapId) then
			return result
		end
		
		local mapInfo = C_Map.GetMapInfo(mapId)
		
		if not mapInfo then
			return
		end
		
		local isMicroDungeon = (mapInfo.mapType == Enum.UIMapType.Micro)
		local _, _, mapName = HBDMigrate:GetLegacyMapInfo(mapId)
		
		if not mapName then
			return result
		end
		
		local mapDirectory
		if isMicroDungeon then
			--todo: reimplement microdungeons
			return result
		else
			mapDirectory = "Interface\\Worldmap\\"..mapName.."\\"
		end

		if db == nil then
			return result
		end
		
		if db.global.overlayData[mapName] == nil then
			db.global.overlayData[mapName] = {}
		end
		
		result = {texData = LuaUtils:clone(db.global.overlayData[mapName] or {})}
		result.mapDirectory = mapDirectory
		return result
	end
	
	local function HarvestCurrentMapOverlayInfo()
		local exploredMaps = C_MapExplorationInfo.GetExploredMapTextures_org(WorldMapFrame:GetMapID())
		
		if exploredMaps and DugisGuideViewer:IsBigMap(WorldMapFrame:GetMapID()) then
			if not DataExport then
				DataExport = {}
			end
			
			--Currently displayed map
			local currentMapId = WorldMapFrame:GetMapID()
			
			if not DataExport[currentMapId] then
				DataExport[currentMapId] = {}
			end
		
			if exploredMaps then
				for i=1, #exploredMaps do
					local exploredMap = LuaUtils:clone(exploredMaps[i])
					exploredMap.hitRect = nil
					exploredMap.isShownByMouseOver = nil
					DataExport[currentMapId][i] = exploredMap
				end
			end
		end
	end
	
	local overlayTextures  = {}
	overlayTexturesGPS  = {}

	function OverrideMapOverlaysUniversal(forWMap)
		if db == nil then
			return
		end
	 
		local discoveredOverlayData = {}
		
		local removeFogForGPSArrow
		
		if DugisGuideViewer.Modules.GPSArrowModule then
			removeFogForGPSArrow = DugisGuideViewer.Modules.GPSArrowModule.Options.removeFog
		end

		if (not DugisGuideViewer:UserSetting(DGV_REMOVEMAPFOG) or DugisGuideViewer.mapsterloaded or not MOD.GuideOn) and #overlayTextures==0 then
			return
		end

	  if forWMap then
		for i = 1, #overlayTextures  do
			overlayTextures[i]:Hide()
		end
	  else
		for i = 1, #overlayTexturesGPS  do
			if type(overlayTexturesGPS[i]) == "table" then
				overlayTexturesGPS[i]:Hide()
			end
		end
	  end
		
		if forWMap then
		wipe(overlayTextures)
		else
		wipe(overlayTexturesGPS)
		end

		local itemIndex = 1
		local item = _G[format("WorldMapOverlay%d", itemIndex)]
		while item do
		  if forWMap then
			tinsert(overlayTextures, item)
		  else
			tinsert(overlayTexturesGPS, item:GetTexture())
		  end
			itemIndex = itemIndex + 1
		    item = _G[format("WorldMapOverlay%d", itemIndex)]
		end
		
		if harvestingDataMode then
			HarvestCurrentMapOverlayInfo()
		end
		
		local texInfo
		
		if forWMap then
			texInfo = GetCurrentMapOverlayData(WorldMapFrame:GetMapID())
		else
			texInfo = GetCurrentMapOverlayData(DugisGuideViewer.Modules.GPSArrowModule.GetMapIdForGPSMap())
		end
		
		local tilesFrame = FindTilesFrame()

		local textureCount = 0
		numOverlayTextures  = #overlayTextures
		local texturePixelWidth, textureFileWidth, texturePixelHeight, textureFileHeight
		
		for texName, texData in pairs(texInfo.texData) do
			local texturePath = texInfo.mapDirectory .. texName
			local textureWidth, textureHeight, offsetX, offsetY = mod(texData, 2^10), mod(floor(texData / 2^10), 2^10), mod(floor(texData / 2^20), 2^10), floor(texData / 2^30)

			local numTexturesWide = ceil(textureWidth / 256)
			local numTexturesTall = ceil(textureHeight / 256)
			local neededTextures = textureCount + (numTexturesWide * numTexturesTall)
			if neededTextures > numOverlayTextures  then
				for j = numOverlayTextures  + 1, neededTextures do
				  if forWMap then
					local texture = tilesFrame:CreateTexture(format("DugiWorldMapOverlay%d", j), "ARTWORK")
					tinsert(overlayTextures , texture)
				  else
					if GPSArrow then
						local textureGPS = GPSArrow:CreateTexture(format("DugiWorldMapOverlayGPS%d", j), "ARTWORK")
						tinsert(overlayTexturesGPS , textureGPS)
					end
				  end
				end
				numOverlayTextures  = neededTextures
			end
			for j = 1, numTexturesTall do
				if j < numTexturesTall then
					texturePixelHeight = 256
					textureFileHeight = 256
				else
					texturePixelHeight = mod(textureHeight, 256)
					if texturePixelHeight == 0 then
						texturePixelHeight = 256
					end
					textureFileHeight = 16
					while textureFileHeight < texturePixelHeight do
						textureFileHeight = textureFileHeight * 2
					end
				end
				for k = 1, numTexturesWide do
				  textureCount = textureCount + 1
					local texture
					local textureGPS
					
					if k < numTexturesWide then
						texturePixelWidth = 256
						textureFileWidth = 256
					else
						texturePixelWidth = mod(textureWidth, 256)
						if texturePixelWidth == 0 then
							texturePixelWidth = 256
						end
						textureFileWidth = 16
						while textureFileWidth < texturePixelWidth do
							textureFileWidth = textureFileWidth * 2
						end
					end
					
				  if forWMap then
					texture = overlayTextures [textureCount]

					texture:SetWidth(texturePixelWidth)
					texture:SetHeight(texturePixelHeight)
					texture:SetTexCoord(0, texturePixelWidth / textureFileWidth, 0, texturePixelHeight / textureFileHeight)
					texture:ClearAllPoints()
					texture:SetPoint("TOPLEFT", (offsetX + (256 * (k-1))), -(offsetY + (256 * (j - 1))))
					texture:SetTexture(format(texturePath.."%d", ((j - 1) * numTexturesWide) + k))
				  else
				    textureGPS = overlayTexturesGPS[textureCount]
					if DugisGuideViewer.Modules.GPSArrowModule then
						if type(textureGPS) ~= "table" then
							overlayTexturesGPS[textureCount] = GPSArrow:CreateTexture(format("DugiWorldMapOverlayGPS%d", textureCount), "ARTWORK")
							overlayTexturesGPS[textureCount]:SetTexture(textureGPS)
							textureGPS = overlayTexturesGPS[textureCount]
						
							local factor = DugisGuideViewer.Modules.GPSArrowModule.GetMapOverlaysFactor()
							textureGPS:SetWidth(texturePixelWidth * factor)
							textureGPS:SetHeight(texturePixelHeight * factor)
							textureGPS:SetTexCoord(0, texturePixelWidth / textureFileWidth, 0, texturePixelHeight / textureFileHeight)
							textureGPS:ClearAllPoints()
							local x = (offsetX + (256  * (k-1)))
							local y = -(offsetY + (256 * (j - 1))) 
							textureGPS:SetPoint("TOPLEFT", _G["GPSArrow"..1]:GetParent(), x * factor, y * factor)
							textureGPS:SetTexture(format(texturePath.."%d", ((j - 1) * numTexturesWide) + k))
							
							textureGPS.orgX = x
							textureGPS.orgY = y
							textureGPS.orgW = texturePixelWidth
							textureGPS.orgH = texturePixelHeight
						end
					end
                  end
					if discoveredOverlayData[texName] then
					  if forWMap then
						texture:SetVertexColor(1, 1, 1)
						texture:SetDrawLayer("ARTWORK")
						texture:Show()
					  else
						if type(textureGPS) == "table" then
							textureGPS:SetVertexColor(1, 1, 1)
							textureGPS:SetDrawLayer("ARTWORK")
							if removeFogForGPSArrow then
								textureGPS:Show()
							else
								textureGPS:Hide()
							end
						end
					  end
					elseif DugisGuideViewer:UserSetting(DGV_REMOVEMAPFOG) or not DugisGuideViewer.mapsterloaded and MOD.GuideOn then
					  if forWMap then
						texture:SetVertexColor(.5, .5, .5)
						texture:SetDrawLayer("BORDER")
						texture:Show()
					  else
						if type(textureGPS) == "table" then
							textureGPS:SetVertexColor(.5, .5, .5)
							textureGPS:SetDrawLayer("BORDER")
							if removeFogForGPSArrow then
									textureGPS:Show()
							else
								textureGPS:Hide()
							end
						end
					  end
					else
					  if forWMap then
						texture:Hide()
					  else
						if type(textureGPS) == "table" then
							textureGPS:Hide()
						end
					  end
					end


				end
			end
		end
		
	  if forWMap then
		for i = textureCount+1, numOverlayTextures  do
			overlayTextures [i]:Hide()
		end	
	  else
		for i = textureCount+1, numOverlayTextures  do
			if type(overlayTexturesGPS[i]) == "table" then
				overlayTexturesGPS[i]:Hide()
			end
		end
      end
		wipe(discoveredOverlayData)

		if not DugisGuideViewer:UserSetting(DGV_REMOVEMAPFOG) or not MOD.GuideOn or DugisGuideViewer.mapsterloaded then
		  if forWMap then
			wipe(overlayTextures)
		  else
			wipe(overlayTexturesGPS)
		  end
		end
	end
	
	function OverrideMapOverlays()
		OverrideMapOverlaysUniversal(true)
		OverrideMapOverlaysUniversal(false)
	end

	-- Code courtesy ckknight
	function MOD:GetCurrentCursorPosition(frame)
	local x, y = GetCursorPosition()
	local left, top = frame:GetLeft(), frame:GetTop()
	local width = frame:GetWidth()
	local height = frame:GetHeight()
	local scale = frame:GetEffectiveScale()
	local cx = (x/scale - left) / width
	local cy = (top - y/scale) / height

		if cx < 0 or cx > 1 or cy < 0 or cy > 1 then
			return nil, nil
	end
	return cx, cy
	end

	local formatCoords = "%.2f, %.2f"


	local UpdateWorldMapFrame = MOD.NoOp
	function MOD:InitializeMapOverlays()
		db = LibStub("AceDB-3.0"):New("MapOverlaysDugis", defaults)
		
		-- todo: find replacement
		--hooksecurefunc("WorldMapFrame_Update", UpdateWorldMapFrame);
		hooksecurefunc(WorldMapFrame, "OnMapChanged", UpdateWorldMapFrame);
		
	end

	function MOD:MapHasOverlays()
		local overlayMap = db.global.overlayData[WorldMapFrame:GetMapID()]
		return overlayMap and next(overlayMap)
	end

	function MapOverlays:Load()
		UpdateWorldMapFrame = function()
			if not MOD.CoordsFrame then
				MOD.CoordsFrame = CreateFrame("Frame", nil, WorldMapFrame)
				MOD.CoordsFrame.Player = MOD.CoordsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
				MOD.CoordsFrame.Cursor = MOD.CoordsFrame:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
				MOD.CoordsFrame:SetScript("OnUpdate", function()
					if MOD:UserSetting(DGV_DISPLAYMAPCOORDINATES)
						and not DugisGuideViewer.mapsterloaded
						and not DugisGuideViewer.tomtomloaded
					then
						local _, _, x, y  = DugisGuideViewer:GetUnitPosition("player", true)
						if not x or not y then
							MOD.CoordsFrame.Player:SetText("|cffffd200玩家:|r ---")
						else
							MOD.CoordsFrame.Player:SetFormattedText("|cffffd200玩家:|r %s", formatCoords:format(x*100, y*100))
						end

						if WorldMapFrame.ScrollContainer.Child:GetLeft() then --prevents error on early load
							local cX, cY = MOD:GetCurrentCursorPosition(WorldMapFrame.ScrollContainer.Child)
							if not cX or not cY then
								MOD.CoordsFrame.Cursor:SetText("|cffffd200游標:|r ---")
							else
								MOD.CoordsFrame.Cursor:SetFormattedText("|cffffd200游標:|r %s", formatCoords:format(cX*100, cY*100))
							end
						end
                        MOD.CoordsFrame:Show()
					else
						MOD.CoordsFrame:Hide()
					end

					if DugisGuideViewer.tomtomloaded
						or MOD:UserSetting(DGV_DISPLAYMAPCOORDINATES)
					then
					
					end
				end)
				MOD.CoordsFrame:Show()
			end

			MOD.CoordsFrame.Player:ClearAllPoints()
			MOD.CoordsFrame.Cursor:ClearAllPoints()
			
			if not WorldMapFrame:IsMaximized() then
				MOD.CoordsFrame.Player:SetPoint("TOPLEFT", WorldMapFrame, "BOTTOMLEFT", 4, -5)
				MOD.CoordsFrame.Cursor:SetPoint("TOPLEFT", WorldMapFrame, "BOTTOMLEFT", 150, -5)
	     	else
				MOD.CoordsFrame.Player:SetPoint("TOPLEFT", WorldMapFrame, "BOTTOM", -150, -30)
				MOD.CoordsFrame.Cursor:SetPoint("TOPLEFT", WorldMapFrame, "BOTTOM", 20, -30)
			end
            
			OverrideMapOverlays()
		end
		MOD:InitializeMapOverlays()
        
        UpdateWorldMapFrame()
	end

	function MapOverlays:Unload()
		OverrideMapOverlays()
		UpdateWorldMapFrame = MOD.NoOp
		if MOD.CoordsFrame then MOD.CoordsFrame:Hide() end
	end
end
