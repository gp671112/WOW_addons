EasyScrap.tooltipReader = CreateFrame('GameTooltip', "EasyScrapTooltipReader", nil, "GameTooltipTemplate")
EasyScrap.tooltipReader:SetOwner(UIParent, "ANCHOR_NONE")