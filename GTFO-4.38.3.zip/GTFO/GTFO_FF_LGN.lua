--------------------------------------------------------------------------
-- GTFO_FF_LGN.lua 
--------------------------------------------------------------------------
--[[
GTFO Friendly Fire List - Legion
Author: Zensunim of Malygos
]]--

-- *********************
-- * The Emerald Dream *
-- *********************

GTFO.FFSpellID["215461"] = {
  --desc = "Necrotic Venom (Elerethe Renferal)";
  sound = 1;
  test = true;
};

GTFO.FFSpellID["203097"] = {
  --desc = "Rot (Nythendra)";
  sound = 1;
};