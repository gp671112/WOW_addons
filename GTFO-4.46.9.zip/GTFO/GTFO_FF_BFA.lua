--------------------------------------------------------------------------
-- GTFO_FF_BFA.lua 
--------------------------------------------------------------------------
--[[
GTFO Friendly Fire List - Battle for Azeroth
Author: Zensunim of Malygos
]]--

-- *********
-- * Uldir *
-- *********

-- TODO: Plasma Discharge (Taloc) -- Alert when standing next to someone that has it
-- TODO: Malodorous Miasma (Fetid Devourer) -- Mythic, spreading
-- TODO: Putrid Paroxysm (Fetid Devourer) -- Mythic, spreading
-- TODO: Imminent Ruin (Mythrax the Unraveler) -- Not sure if this is trackable
