The following files are released under licenses which allow use in at least non-commercial applications.

yanone.ttf, Yanone Kaffeesatz Bold by [Yanone](yanone.de) under [SIL Open Font License](http://scripts.sil.org/cms/scripts/page.php?item_id=OFL_web)

francois.ttf, Francois One by [newtypography.co.uk](New Typography) under [SIL Open Font License](http://scripts.sil.org/cms/scripts/page.php?item_id=OFL_web)

roboto.ttf, Roboto Condensed Bold by [Google](fonts.google.com) under [Apache License](https://raw.githubusercontent.com/google/roboto/master/LICENSE)
