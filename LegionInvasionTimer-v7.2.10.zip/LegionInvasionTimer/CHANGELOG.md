# LegionInvasionTimer

## [v7.2.10](https://github.com/funkydude/LegionInvasionTimer/tree/v7.2.10) (2017-05-09) [](#top)
[Full Changelog](https://github.com/funkydude/LegionInvasionTimer/compare/v7.2.9...v7.2.10)

- cleanups  
- Fix war supplies option name.  
- Update deDE.lua (#62)  
- Update zhCN.lua (#61)  
- koKR update (#60)  
