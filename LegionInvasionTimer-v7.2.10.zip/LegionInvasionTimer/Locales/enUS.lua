
local _, mod = ...
mod.L = {}
local L = mod.L

L.firstRunWarning = "Timers will not be shown until you see your first invasion."
L.underAttack = "|T236292:15:15:0:0:64:64:4:60:4:60|t %s is under attack!"
L.tooltipClick = "|cffeda55fClick|r to drag and move."
L.tooltipClickOptions = "|cffeda55fRight-Click|r to open options."
L.nextInvasions = "Next Invasions"
L.next = "Next"
L.waiting = "Waiting"
