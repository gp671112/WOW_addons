
if GetLocale() ~= "zhTW" then return end
local _, mod = ...
local L = mod.L

L.firstRunWarning = "計時條不會顯示直到你看見第一個入侵。"
L.underAttack = "|T236292:15:15:0:0:64:64:4:60:4:60|t %s 被攻擊了!"
L.tooltipClick = "|cffeda55f左鍵點擊|r 拖曳與移動。"
L.tooltipClickOptions = "|cffeda55f右鍵點擊|r 開啟選項。"
L.nextInvasions = "下次入侵"
L.next = "下次"
L.waiting = "等候"