local L = LibStub("AceLocale-3.0"):NewLocale("MythicPlusLoot", "enUS", true)

L["MythicPlusLoot: Loaded"] = true
L["MythicPlusLoot: Enabled"] = true
L["MythicPlusLoot: Disabled"] = true
L["MythicPlusLoot does not have any function command."] = true

L["This shows the level of the item you'll find in this week's chest."] = true
L["Weekly Chest Reward"] = true

L["Loot Item Level: "] = true
L["Weekly Chest Item Level: "] = true