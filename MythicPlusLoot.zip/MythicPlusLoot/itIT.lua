local L = LibStub("AceLocale-3.0"):NewLocale("MythicPlusLoot", "itIT")
if not L then return end

L["MythicPlusLoot: Loaded"] = "MythicPlusLoot: Caricato"
L["MythicPlusLoot: Enabled"] = "MythicPlusLoot: Abilitato"
L["MythicPlusLoot: Disabled"] = "MythicPlusLoot: Disabilitato"
L["MythicPlusLoot does not have any function command."] = "MythicPlusLoot non ha alcun comando valido."

L["This shows the level of the item you'll find in this week's chest."] = "Mostra l'item level dell'oggetto che troverai nel forziere di questa settimana."
L["Weekly Chest Reward"] = "Premio Forziere Settimanale"

L["Loot Item Level: "] = "Item Level Bottino: "
L["Weekly Chest Item Level: "] = "Item Level Forziere Settimanale: "