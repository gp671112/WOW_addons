local L = LibStub("AceLocale-3.0"):NewLocale("MythicPlusLoot", "koKR")
if not L then return end


--by Elnarfim
L["MythicPlusLoot: Loaded"] = "MythicPlusLoot: 로드됨"
L["MythicPlusLoot: Enabled"] = "MythicPlusLoot: 활성화"
L["MythicPlusLoot: Disabled"] = "MythicPlusLoot: 비활성화"
L["MythicPlusLoot does not have any function command."] = "MythicPlusLoot은 슬래시 명령어를 제공하지 않습니다."

L["This shows the level of the item you'll find in this week's chest."] = "목요일에 상자에서 나올 아이템 레벨을 표시합니다."
L["Weekly Chest Reward"] = "주간 상자 보상"

L["Loot Item Level: "] = "전리품 아이템 레벨: "
L["Weekly Chest Item Level: "] = "주간 상자 아이템 레벨: "