local L = LibStub("AceLocale-3.0"):NewLocale("MythicPlusLoot", "zhCN")
if not L then return end

--by Azpilicuet@主宰之剑
L["MythicPlusLoot: Loaded"] = "MythicPlusLoot: 已载入"
L["MythicPlusLoot: Enabled"] = "MythicPlusLoot: 启用"
L["MythicPlusLoot: Disabled"] = "MythicPlusLoot: 停用"
L["MythicPlusLoot does not have any function command."] = "MythicPlusLoot沒有任何设置命令."

L["This shows the level of the item you'll find in this week's chest."] = "这里显示你在下周职业大厅宝箱获得物品的等级."
L["Weekly Chest Reward"] = "职业大厅宝箱奖励"

L["Loot Item Level: "] = "副本拾取物品等級: "
L["Weekly Chest Item Level: "] = "职业大厅宝箱物品等級: "