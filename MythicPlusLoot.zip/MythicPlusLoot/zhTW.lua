local L = LibStub("AceLocale-3.0"):NewLocale("MythicPlusLoot", "zhTW")
if not L then return end


--by gaspy10
L["MythicPlusLoot: Loaded"] = "MythicPlusLoot: 已載入"
L["MythicPlusLoot: Enabled"] = "MythicPlusLoot: 已啟用"
L["MythicPlusLoot: Disabled"] = "MythicPlusLoot: 已停用"
L["MythicPlusLoot does not have any function command."] = "MythicPlusLoot 沒有任何功能指令。"

L["This shows the level of the item you'll find in this week's chest."] = "顯示每週寶箱可以開到的獎勵物品等級。"
L["Weekly Chest Reward"] = "每週寶箱獎勵"

L["Loot Item Level: "] = "戰利品等級："
L["Weekly Chest Item Level: "] = "每週寶箱物品等級："




