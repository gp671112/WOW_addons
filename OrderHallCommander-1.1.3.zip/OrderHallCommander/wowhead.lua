local me,ns = ...

ns.wowhead_update=1488785721
-- DataMined from WowHead other-consumables?filter=224;1;0 on 06/03/2017
-- Contains 367 items
ns.allArtifactPower=
{
  ["140410"] = {
    name = {
      "4Mark of the Rogues"
    },
    Power = 1000
  },
  ["140492"] = {
    name = {
      "6Gleaming Glacial Pebble"
    },
    Power = 150
  },
  ["139614"] = {
    name = {
      "6Azsharan Manapearl"
    },
    Power = 175
  },
  ["141707"] = {
    name = {
      "5Smuggled Magical Supplies"
    },
    Power = 520
  },
  ["130144"] = {
    name = {
      "5Crystallized Fey Darter Egg"
    },
    Power = 0
  },
  ["142555"] = {
    name = {
      "4Aoire's Crook"
    },
    Power = 300
  },
  ["141701"] = {
    name = {
      "5Selfless Glory"
    },
    Power = 100
  },
  ["141386"] = {
    name = {
      "5Giant Pearl Scepter"
    },
    Power = 100
  },
  ["143486"] = {
    name = {
      "4Arcshaper's Barrier"
    },
    Power = 250
  },
  ["141706"] = {
    name = {
      "6Carved Oaken Windchimes"
    },
    Power = 210
  },
  ["140471"] = {
    name = {
      "6Lord Shalzaru's Relic"
    },
    Power = 150
  },
  ["147201"] = {
    name = {
      "5Gladiator's Glory"
    },
    Power = 240
  },
  ["132923"] = {
    name = {
      "5Hrydshal Etching"
    },
    Power = 0
  },
  ["141671"] = {
    name = {
      "5Moon Guard Focusing Stone"
    },
    Power = 300
  },
  ["140510"] = {
    name = {
      "6Iron Black Rook Hold Key"
    },
    Power = 150
  },
  ["141896"] = {
    name = {
      "5Nashal's Spyglass"
    },
    Power = 45
  },
  ["141670"] = {
    name = {
      "5Arcane Trap Power Core"
    },
    Power = 300
  },
  ["141949"] = {
    name = {
      "5Everburning Arcane Glowlamp"
    },
    Power = 300
  },
  ["141858"] = {
    name = {
      "6Soldier's Worth"
    },
    Power = 100
  },
  ["140305"] = {
    name = {
      "4Brimming Essence"
    },
    Power = 2000
  },
  ["143677"] = {
    name = {
      "6Gladiator's Exultation"
    },
    Power = 90
  },
  ["138487"] = {
    name = {
      "6Shinfel's Staff of Torment"
    },
    Power = 100
  },
  ["140490"] = {
    name = {
      "6Wooden Snow Shoes"
    },
    Power = 150
  },
  ["131784"] = {
    name = {
      "5Left Half of a Locket"
    },
    Power = 0
  },
  ["143715"] = {
    name = {
      "5Gladiator's Revelry"
    },
    Power = 180
  },
  ["138732"] = {
    name = {
      "6History of the Blade"
    },
    Power = 10
  },
  ["141388"] = {
    name = {
      "5Warden's Boon"
    },
    Power = 100
  },
  ["147198"] = {
    name = {
      "6Gladiator's Exultation"
    },
    Power = 200
  },
  ["141393"] = {
    name = {
      "5Onyx Arrowhead"
    },
    Power = 100
  },
  ["141943"] = {
    name = {
      "5Moon Guard Power Gem"
    },
    Power = 300
  },
  ["140478"] = {
    name = {
      "6Painted Bark"
    },
    Power = 150
  },
  ["139511"] = {
    name = {
      "6Hallowed Runestone"
    },
    Power = 250
  },
  ["143741"] = {
    name = {
      "4Blessed Kaldorei Banner"
    },
    Power = 250
  },
  ["140508"] = {
    name = {
      "6Nightborne Artificer's Ring"
    },
    Power = 100
  },
  ["141946"] = {
    name = {
      "5Trident of Sashj'tar"
    },
    Power = 300
  },
  ["140487"] = {
    name = {
      "6War-Damaged Vrykul Helmet"
    },
    Power = 100
  },
  ["139506"] = {
    name = {
      "4Greater Glory of the Order"
    },
    Power = 1000
  },
  ["138782"] = {
    name = {
      "4Brief History of the Ages"
    },
    Power = 100
  },
  ["141877"] = {
    name = {
      "5Coura's Ancient Scepter"
    },
    Power = 40
  },
  ["143740"] = {
    name = {
      "4Enchanted Sin'dorei Banner"
    },
    Power = 250
  },
  ["143714"] = {
    name = {
      "5Gladiator's Glory"
    },
    Power = 120
  },
  ["138885"] = {
    name = {
      "6Treasure of the Ages"
    },
    Power = 35
  },
  ["141676"] = {
    name = {
      "4The Valewatcher's Boon"
    },
    Power = 1000
  },
  ["130165"] = {
    name = {
      "5Heathrow Keepsake"
    },
    Power = 0
  },
  ["141892"] = {
    name = {
      "5Gilbert's Finest"
    },
    Power = 35
  },
  ["141383"] = {
    name = {
      "5Crystallized Moon Drop"
    },
    Power = 100
  },
  ["140370"] = {
    name = {
      "6Amber Shard"
    },
    Power = 150
  },
  ["138881"] = {
    name = {
      "5Soldier's Glory"
    },
    Power = 400
  },
  ["140357"] = {
    name = {
      "6Fel Lava Rock"
    },
    Power = 150
  },
  ["143333"] = {
    name = {
      "4Badge of Vengeance"
    },
    Power = 500
  },
  ["141389"] = {
    name = {
      "5Stareye Gem"
    },
    Power = 100
  },
  ["144270"] = {
    name = {
      "6Fel-Scarred Tomb Stone"
    },
    Power = 250
  },
  ["141681"] = {
    name = {
      "4Valewalker Talisman"
    },
    Power = 1000
  },
  ["139616"] = {
    name = {
      "5Dropper of Nightwell Liquid"
    },
    Power = 475
  },
  ["138816"] = {
    name = {
      "5Adventurer's Glory"
    },
    Power = 100
  },
  ["141709"] = {
    name = {
      "5Ancient Champion Effigy"
    },
    Power = 550
  },
  ["141677"] = {
    name = {
      "4Key to the Bazaar"
    },
    Power = 800
  },
  ["143743"] = {
    name = {
      "4Highly Charged Mana Clog"
    },
    Power = 250
  },
  ["141855"] = {
    name = {
      "5History of the Aeons"
    },
    Power = 125
  },
  ["143747"] = {
    name = {
      "4Key to the Nighthold"
    },
    Power = 800
  },
  ["140466"] = {
    name = {
      "6Corroded Eternium Rose"
    },
    Power = 100
  },
  ["140517"] = {
    name = {
      "4Glory of the Order"
    },
    Power = 300
  },
  ["142455"] = {
    name = {
      "4Demonic Command Shards"
    },
    Power = 1000
  },
  ["143488"] = {
    name = {
      "5Enchanted Nightborne Coin"
    },
    Power = 100
  },
  ["141927"] = {
    name = {
      "6Burrowing Worm Mandible"
    },
    Power = 180
  },
  ["141890"] = {
    name = {
      "6Petrified Acorn"
    },
    Power = 50
  },
  ["127999"] = {
    name = {
      "6Shard of Potentiation"
    },
    Power = 0
  },
  ["140251"] = {
    name = {
      "5Purified Satyr Totem"
    },
    Power = 350
  },
  ["143538"] = {
    name = {
      "4Entangled Telemancy Orb"
    },
    Power = 250
  },
  ["128026"] = {
    name = {
      "4Trembling Phylactery"
    },
    Power = 0
  },
  ["143844"] = {
    name = {
      "5Glory of Combat"
    },
    Power = 250
  },
  ["140469"] = {
    name = {
      "6Felslate Arrowhead"
    },
    Power = 100
  },
  ["143742"] = {
    name = {
      "4Scepter of Kerxan"
    },
    Power = 250
  },
  ["141387"] = {
    name = {
      "5Emerald Bloom"
    },
    Power = 100
  },
  ["141942"] = {
    name = {
      "5Managazer's Petrifying Eye"
    },
    Power = 350
  },
  ["138784"] = {
    name = {
      "5Questor's Glory"
    },
    Power = 100
  },
  ["144271"] = {
    name = {
      "6Searing Hellion Claw"
    },
    Power = 155
  },
  ["140358"] = {
    name = {
      "6Eredar Armor Clasp"
    },
    Power = 150
  },
  ["138813"] = {
    name = {
      "5Adventurer's Resounding Renown"
    },
    Power = 100
  },
  ["140685"] = {
    name = {
      "5Enchanted Sunrunner Kidney"
    },
    Power = 25
  },
  ["140386"] = {
    name = {
      "5Inquisitor's Shadow Orb"
    },
    Power = 40
  },
  ["141397"] = {
    name = {
      "5The Spiritwalker's Wisdom"
    },
    Power = 100
  },
  ["142004"] = {
    name = {
      "5Nar'thalas Research Tome"
    },
    Power = 400
  },
  ["141944"] = {
    name = {
      "5Empowered Half-Shell"
    },
    Power = 300
  },
  ["139512"] = {
    name = {
      "5Sigilstone of Tribute"
    },
    Power = 490
  },
  ["141699"] = {
    name = {
      "5Boon of the Companion"
    },
    Power = 0
  },
  ["143744"] = {
    name = {
      "4Blessed Ravencrest Blades"
    },
    Power = 250
  },
  ["141310"] = {
    name = {
      "5Falanaar Crescent"
    },
    Power = 100
  },
  ["143499"] = {
    name = {
      "4Overcharged Infiltrator's Mask"
    },
    Power = 250
  },
  ["143540"] = {
    name = {
      "4Undertuned Attunement Crystal"
    },
    Power = 500
  },
  ["138785"] = {
    name = {
      "5Adventurer's Resounding Glory"
    },
    Power = 400
  },
  ["141399"] = {
    name = {
      "5Overcharged Stormscale"
    },
    Power = 100
  },
  ["140310"] = {
    name = {
      "6Crude Statuette"
    },
    Power = 10
  },
  ["141887"] = {
    name = {
      "6Lucky Brulstone"
    },
    Power = 50
  },
  ["139509"] = {
    name = {
      "6Worldtree Bloom"
    },
    Power = 245
  },
  ["131808"] = {
    name = {
      "5Engraved Bloodtotem Armlet"
    },
    Power = 25
  },
  ["141024"] = {
    name = {
      "5Seal of Leadership"
    },
    Power = 500
  },
  ["142534"] = {
    name = {
      "4Plume of the Fallen Val'kyr"
    },
    Power = 600
  },
  ["138781"] = {
    name = {
      "5Brief History of the Aeons"
    },
    Power = 75
  },
  ["142002"] = {
    name = {
      "5Dragonscale of the Earth Aspect"
    },
    Power = 400
  },
  ["141705"] = {
    name = {
      "6Disorganized Ravings"
    },
    Power = 205
  },
  ["141396"] = {
    name = {
      "5The River's Blessing"
    },
    Power = 100
  },
  ["130152"] = {
    name = {
      "5Condensed Light of Elune"
    },
    Power = 35
  },
  ["140374"] = {
    name = {
      "6Jagged Worgen Fang"
    },
    Power = 150
  },
  ["141921"] = {
    name = {
      "6Dessicated Blue Dragonscale"
    },
    Power = 170
  },
  ["141853"] = {
    name = {
      "5Accolade of Myth"
    },
    Power = 0
  },
  ["141405"] = {
    name = {
      "5Senegos' Favor"
    },
    Power = 100
  },
  ["140388"] = {
    name = {
      "5Falanaar Gemstone"
    },
    Power = 40
  },
  ["147199"] = {
    name = {
      "6Gladiator's Triumph"
    },
    Power = 125
  },
  ["143716"] = {
    name = {
      "4Soldier's Legacy"
    },
    Power = 800
  },
  ["141384"] = {
    name = {
      "5Emblem of the Dark Covenant"
    },
    Power = 100
  },
  ["141703"] = {
    name = {
      "6Witch-Harpy Talon"
    },
    Power = 190
  },
  ["141639"] = {
    name = {
      "5Falanaar Orb"
    },
    Power = 300
  },
  ["142454"] = {
    name = {
      "4Viz'aduum's Eye"
    },
    Power = 500
  },
  ["141690"] = {
    name = {
      "5Symbol of Victory"
    },
    Power = 35
  },
  ["141392"] = {
    name = {
      "5Fragment of the Soulcage"
    },
    Power = 100
  },
  ["141872"] = {
    name = {
      "5Artisan's Handiwork"
    },
    Power = 150
  },
  ["140474"] = {
    name = {
      "6Nar'thalas Pottery Fragment"
    },
    Power = 100
  },
  ["132361"] = {
    name = {
      "5Petrified Arkhana"
    },
    Power = 0
  },
  ["134133"] = {
    name = {
      "4Jewel of Brilliance"
    },
    Power = 0
  },
  ["140409"] = {
    name = {
      "4Tome of Dimensional Awareness"
    },
    Power = 900
  },
  ["140421"] = {
    name = {
      "4Ancient Qiraji Idol"
    },
    Power = 1200
  },
  ["143745"] = {
    name = {
      "4Ley-Syphoner's Focus"
    },
    Power = 500
  },
  ["140512"] = {
    name = {
      "6Oversized Drinking Mug"
    },
    Power = 150
  },
  ["141922"] = {
    name = {
      "6Brulstone Fishing Sinker"
    },
    Power = 220
  },
  ["141953"] = {
    name = {
      "4Nightglow Energy Vessel"
    },
    Power = 1000
  },
  ["140422"] = {
    name = {
      "4Moonglow Idol"
    },
    Power = 750
  },
  ["140520"] = {
    name = {
      "6Amethyst Geode"
    },
    Power = 100
  },
  ["140306"] = {
    name = {
      "5Mark of the Valorous"
    },
    Power = 1000
  },
  ["140373"] = {
    name = {
      "6Ornamented Boot Strap"
    },
    Power = 150
  },
  ["141704"] = {
    name = {
      "6Forgotten Offering"
    },
    Power = 210
  },
  ["144266"] = {
    name = {
      "6Shattered Wrathguard Horn"
    },
    Power = 175
  },
  ["140484"] = {
    name = {
      "6Well-Used Drinking Horn"
    },
    Power = 100
  },
  ["141954"] = {
    name = {
      "4'Borrowed' Highborne Magi's Chalice"
    },
    Power = 650
  },
  ["140491"] = {
    name = {
      "6Stolen Pearl Ring"
    },
    Power = 150
  },
  ["142005"] = {
    name = {
      "5Vial of Diluted Nightwell Liquid"
    },
    Power = 400
  },
  ["141955"] = {
    name = {
      "4Corrupted Duskmere Crest"
    },
    Power = 450
  },
  ["141937"] = {
    name = {
      "5Eredari Ignition Crystal"
    },
    Power = 350
  },
  ["140497"] = {
    name = {
      "6Bundle of Tiny Spears"
    },
    Power = 100
  },
  ["142535"] = {
    name = {
      "4Soulcatcher of the Encroaching Mist"
    },
    Power = 200
  },
  ["131795"] = {
    name = {
      "5Nar'thalasian Corsage"
    },
    Power = 35
  },
  ["141667"] = {
    name = {
      "4Ancient Keeper's Brooch"
    },
    Power = 800
  },
  ["143536"] = {
    name = {
      "4Overloaded Scrying Orb"
    },
    Power = 250
  },
  ["138886"] = {
    name = {
      "5Favor of Valarjar"
    },
    Power = 150
  },
  ["141947"] = {
    name = {
      "5Mark of Lunastre"
    },
    Power = 300
  },
  ["144268"] = {
    name = {
      "6Alliance Infantry Blade"
    },
    Power = 220
  },
  ["141950"] = {
    name = {
      "4Arcane Seed Case"
    },
    Power = 800
  },
  ["144267"] = {
    name = {
      "6Bloodied Horde Axe Head"
    },
    Power = 195
  },
  ["140847"] = {
    name = {
      "5Ancient Workshop Focusing Crystal"
    },
    Power = 300
  },
  ["141928"] = {
    name = {
      "6Reaver's Harpoon Head"
    },
    Power = 185
  },
  ["140384"] = {
    name = {
      "5Azsharan Court Scepter"
    },
    Power = 80
  },
  ["141683"] = {
    name = {
      "4Mana-Injected Chronarch Power Core"
    },
    Power = 500
  },
  ["142007"] = {
    name = {
      "5Omnibus: The Schools of Arcane Magic"
    },
    Power = 400
  },
  ["141403"] = {
    name = {
      "5Tablet of Tyr"
    },
    Power = 100
  },
  ["141638"] = {
    name = {
      "5Falanaar Scepter"
    },
    Power = 200
  },
  ["131785"] = {
    name = {
      "5Right Half of a Locket"
    },
    Power = 0
  },
  ["140445"] = {
    name = {
      "4Arcfruit"
    },
    Power = 875
  },
  ["140525"] = {
    name = {
      "6Obsidian Mirror"
    },
    Power = 150
  },
  ["138786"] = {
    name = {
      "5Talisman of Victory"
    },
    Power = 0
  },
  ["141674"] = {
    name = {
      "5Brand of a Blood Brother"
    },
    Power = 300
  },
  ["147203"] = {
    name = {
      "4Soldier's Legacy"
    },
    Power = 1600
  },
  ["128022"] = {
    name = {
      "6Treasured Coin"
    },
    Power = 0
  },
  ["132897"] = {
    name = {
      "5Mandate of the Watchers"
    },
    Power = 45
  },
  ["138880"] = {
    name = {
      "5Soldier's Grit"
    },
    Power = 200
  },
  ["143746"] = {
    name = {
      "4Fel-Dipped Blade"
    },
    Power = 500
  },
  ["141930"] = {
    name = {
      "6Smolderhide Spirit Beads"
    },
    Power = 175
  },
  ["141711"] = {
    name = {
      "5Ancient Druidic Carving"
    },
    Power = 515
  },
  ["140532"] = {
    name = {
      "6Inscribed Vrykul Runestone"
    },
    Power = 150
  },
  ["141675"] = {
    name = {
      "5Deepwater Blossom"
    },
    Power = 300
  },
  ["140304"] = {
    name = {
      "5Activated Essence"
    },
    Power = 250
  },
  ["140322"] = {
    name = {
      "6Trainer's Insight"
    },
    Power = 100
  },
  ["140530"] = {
    name = {
      "6Opalescent Shell"
    },
    Power = 150
  },
  ["130149"] = {
    name = {
      "5Carved Smolderhide Figurines"
    },
    Power = 0
  },
  ["140461"] = {
    name = {
      "6Battered Trophy"
    },
    Power = 100
  },
  ["140528"] = {
    name = {
      "6Dalaran Wine Glass"
    },
    Power = 150
  },
  ["139617"] = {
    name = {
      "5Ancient Warden Manacles"
    },
    Power = 350
  },
  ["140504"] = {
    name = {
      "6Kvaldir Anchor Line"
    },
    Power = 100
  },
  ["140522"] = {
    name = {
      "6Petrified Spiderweb"
    },
    Power = 150
  },
  ["140366"] = {
    name = {
      "6Scarlet Hymnal"
    },
    Power = 100
  },
  ["140519"] = {
    name = {
      "6Whispering Totem"
    },
    Power = 100
  },
  ["143757"] = {
    name = {
      "4Headpiece of the Shadow Council"
    },
    Power = 3000
  },
  ["138812"] = {
    name = {
      "5Adventurer's Wisdom"
    },
    Power = 35
  },
  ["140516"] = {
    name = {
      "6Elemental Bracers"
    },
    Power = 100
  },
  ["141394"] = {
    name = {
      "5Plume of the Great Eagle"
    },
    Power = 100
  },
  ["141948"] = {
    name = {
      "5Token of a Master Cultivator"
    },
    Power = 300
  },
  ["140513"] = {
    name = {
      "6Dreadlord's Commendation"
    },
    Power = 150
  },
  ["140365"] = {
    name = {
      "6Dried Stratholme Lily"
    },
    Power = 100
  },
  ["141941"] = {
    name = {
      "5Crystallized Sablehorn Antler"
    },
    Power = 350
  },
  ["139611"] = {
    name = {
      "6Primitive Roggtotem"
    },
    Power = 165
  },
  ["140255"] = {
    name = {
      "5Enchanted Nightborne Coin"
    },
    Power = 100
  },
  ["140509"] = {
    name = {
      "6Demon-Scrawled Drawing"
    },
    Power = 150
  },
  ["140505"] = {
    name = {
      "6Sweaty Bandanna"
    },
    Power = 100
  },
  ["140507"] = {
    name = {
      "6Unlabeled Potion"
    },
    Power = 100
  },
  ["140523"] = {
    name = {
      "6Crimson Cavern Mushroom"
    },
    Power = 150
  },
  ["138865"] = {
    name = {
      "6Gladiator's Triumph"
    },
    Power = 60
  },
  ["140387"] = {
    name = {
      "6Bracer Gemstone"
    },
    Power = 150
  },
  ["131753"] = {
    name = {
      "5Prayers to the Earthmother"
    },
    Power = 35
  },
  ["140494"] = {
    name = {
      "6Eredar Tail-Cuff"
    },
    Power = 150
  },
  ["140489"] = {
    name = {
      "6Ettin Toe Ring"
    },
    Power = 150
  },
  ["140488"] = {
    name = {
      "6Huge Blacksmith's Hammer"
    },
    Power = 100
  },
  ["140381"] = {
    name = {
      "5Jandvik Jarl's Ring, and Finger"
    },
    Power = 40
  },
  ["142003"] = {
    name = {
      "5Talisman of the Ascended"
    },
    Power = 400
  },
  ["140486"] = {
    name = {
      "6Storm Drake Scale"
    },
    Power = 100
  },
  ["140485"] = {
    name = {
      "6Duskpelt Fang"
    },
    Power = 100
  },
  ["140482"] = {
    name = {
      "6Storm Drake Fang"
    },
    Power = 150
  },
  ["140481"] = {
    name = {
      "6Shimmering Hourglass"
    },
    Power = 150
  },
  ["140480"] = {
    name = {
      "6Drained Construct Core"
    },
    Power = 150
  },
  ["140479"] = {
    name = {
      "6Broken Legion Communicator"
    },
    Power = 150
  },
  ["140244"] = {
    name = {
      "5Jandvik Jarl's Pendant Stone"
    },
    Power = 350
  },
  ["141385"] = {
    name = {
      "5Tidestone Sliver"
    },
    Power = 100
  },
  ["140477"] = {
    name = {
      "6Inert Ashes"
    },
    Power = 100
  },
  ["144272"] = {
    name = {
      "5Seal of Bravery"
    },
    Power = 500
  },
  ["141402"] = {
    name = {
      "5Odyn's Watchful Gaze"
    },
    Power = 100
  },
  ["141313"] = {
    name = {
      "4Manafused Fal'dorei Egg Sac"
    },
    Power = 500
  },
  ["140476"] = {
    name = {
      "6Astranaar Globe"
    },
    Power = 100
  },
  ["141401"] = {
    name = {
      "5Renewed Lifeblood"
    },
    Power = 100
  },
  ["140475"] = {
    name = {
      "6Morning Glory Vine"
    },
    Power = 100
  },
  ["140473"] = {
    name = {
      "6Night-forged Halberd"
    },
    Power = 100
  },
  ["140470"] = {
    name = {
      "6Ancient Gilnean Locket"
    },
    Power = 100
  },
  ["140444"] = {
    name = {
      "4Dream Tear"
    },
    Power = 1250
  },
  ["141932"] = {
    name = {
      "4Shard of Compacted Energy"
    },
    Power = 750
  },
  ["141859"] = {
    name = {
      "5Soldier's Splendor"
    },
    Power = 250
  },
  ["140468"] = {
    name = {
      "6Eagle Eggshell Fragment"
    },
    Power = 100
  },
  ["141673"] = {
    name = {
      "4Love-Laced Arrow"
    },
    Power = 350
  },
  ["131751"] = {
    name = {
      "5Fractured Portal Shard"
    },
    Power = 35
  },
  ["140349"] = {
    name = {
      "5Spare Arcane Ward"
    },
    Power = 100
  },
  ["140467"] = {
    name = {
      "6Fel-Infused Shell"
    },
    Power = 100
  },
  ["142001"] = {
    name = {
      "5Antler of Cenarius"
    },
    Power = 400
  },
  ["141883"] = {
    name = {
      "6Azsharan Keepsake"
    },
    Power = 50
  },
  ["139508"] = {
    name = {
      "6Dried Worldtree Seeds"
    },
    Power = 160
  },
  ["140462"] = {
    name = {
      "6Draketaming Spurs"
    },
    Power = 100
  },
  ["140529"] = {
    name = {
      "6Felstalker's Ring"
    },
    Power = 150
  },
  ["139615"] = {
    name = {
      "6Untapped Mana Gem"
    },
    Power = 230
  },
  ["139609"] = {
    name = {
      "6Depleted Cadet's Wand"
    },
    Power = 235
  },
  ["141395"] = {
    name = {
      "5Stonedark's Pledge"
    },
    Power = 100
  },
  ["131728"] = {
    name = {
      "5Urn of Malgalor's Blood"
    },
    Power = 0
  },
  ["141857"] = {
    name = {
      "6Soldier's Exertion"
    },
    Power = 150
  },
  ["140459"] = {
    name = {
      "6Moon Lily"
    },
    Power = 100
  },
  ["140393"] = {
    name = {
      "6Repentia's Whip"
    },
    Power = 150
  },
  ["140392"] = {
    name = {
      "6Safety Valve"
    },
    Power = 150
  },
  ["140391"] = {
    name = {
      "6Argussian Diamond"
    },
    Power = 150
  },
  ["141929"] = {
    name = {
      "6Hippogryph Plumage"
    },
    Power = 220
  },
  ["140382"] = {
    name = {
      "6Tiny War Drum"
    },
    Power = 100
  },
  ["141956"] = {
    name = {
      "6Rotten Spellbook"
    },
    Power = 200
  },
  ["142533"] = {
    name = {
      "4Titan's Boon"
    },
    Power = 600
  },
  ["139613"] = {
    name = {
      "5Tale-Teller's Staff"
    },
    Power = 450
  },
  ["140389"] = {
    name = {
      "6Petrified Flame"
    },
    Power = 150
  },
  ["140498"] = {
    name = {
      "6Legion Admirer's Note"
    },
    Power = 150
  },
  ["141945"] = {
    name = {
      "5Magically-Fortified Vial"
    },
    Power = 300
  },
  ["141023"] = {
    name = {
      "5Seal of Victory"
    },
    Power = 150
  },
  ["141679"] = {
    name = {
      "4Cobalt Amber Crystal"
    },
    Power = 800
  },
  ["143533"] = {
    name = {
      "4Infused Pit Lord Tusk"
    },
    Power = 500
  },
  ["130153"] = {
    name = {
      "5Godafoss Essence"
    },
    Power = 0
  },
  ["140383"] = {
    name = {
      "6Glowing Cave Mushroom"
    },
    Power = 100
  },
  ["140380"] = {
    name = {
      "6Swiftflight's Tail Feather"
    },
    Power = 100
  },
  ["140379"] = {
    name = {
      "6Broken Warden Glaive Blade"
    },
    Power = 100
  },
  ["139608"] = {
    name = {
      "6Brittle Spelltome"
    },
    Power = 150
  },
  ["140377"] = {
    name = {
      "6Broken Medallion of Karabor"
    },
    Power = 100
  },
  ["140371"] = {
    name = {
      "6Letter from Exarch Maladaar"
    },
    Power = 150
  },
  ["147200"] = {
    name = {
      "5Soldier's Glory"
    },
    Power = 600
  },
  ["140368"] = {
    name = {
      "6Tarnished Engagement Ring"
    },
    Power = 100
  },
  ["140367"] = {
    name = {
      "6Tattered Sheet Music"
    },
    Power = 100
  },
  ["141678"] = {
    name = {
      "4Night Devint: The Perfection of Arcwine"
    },
    Power = 650
  },
  ["141876"] = {
    name = {
      "5Soul-Powered Containment Unit"
    },
    Power = 25
  },
  ["140521"] = {
    name = {
      "6Fire Turtle Shell Fragment"
    },
    Power = 150
  },
  ["140364"] = {
    name = {
      "6Frostwyrm Bone Fragment"
    },
    Power = 100
  },
  ["140369"] = {
    name = {
      "6Scrawled Recipe"
    },
    Power = 150
  },
  ["140359"] = {
    name = {
      "6Darkened Eyeball"
    },
    Power = 150
  },
  ["143713"] = {
    name = {
      "5Skirmisher's Mastery"
    },
    Power = 100
  },
  ["138480"] = {
    name = {
      "6Black Harvest Tome"
    },
    Power = 100
  },
  ["141391"] = {
    name = {
      "5Ashildir's Unending Courage"
    },
    Power = 100
  },
  ["141891"] = {
    name = {
      "5Branch of Shaladrassil"
    },
    Power = 45
  },
  ["132950"] = {
    name = {
      "5Petrified Snake"
    },
    Power = 35
  },
  ["139610"] = {
    name = {
      "5Musty Azsharan Grimoire"
    },
    Power = 465
  },
  ["139507"] = {
    name = {
      "6Cracked Vrykul Insignia"
    },
    Power = 170
  },
  ["131802"] = {
    name = {
      "5Offering to Ram'Pag"
    },
    Power = 45
  },
  ["147202"] = {
    name = {
      "5Gladiator's Revelry"
    },
    Power = 360
  },
  ["141886"] = {
    name = {
      "6Crackling Dragonscale"
    },
    Power = 50
  },
  ["131789"] = {
    name = {
      "5Handmade Mobile"
    },
    Power = 0
  },
  ["131778"] = {
    name = {
      "5Woodcarved Rabbit"
    },
    Power = 0
  },
  ["131758"] = {
    name = {
      "5Oversized Acorn"
    },
    Power = 0
  },
  ["141398"] = {
    name = {
      "5Blessing of the Watchers"
    },
    Power = 100
  },
  ["140385"] = {
    name = {
      "6Legion Pamphlet"
    },
    Power = 100
  },
  ["140241"] = {
    name = {
      "5Enchanted Moonfall Text"
    },
    Power = 300
  },
  ["141689"] = {
    name = {
      "5Jewel of Victory"
    },
    Power = 0
  },
  ["130159"] = {
    name = {
      "5Ravencrest Shield"
    },
    Power = 0
  },
  ["130160"] = {
    name = {
      "5Vial of Pure Moonrest Water"
    },
    Power = 0
  },
  ["142006"] = {
    name = {
      "5Ceremonial Warden Glaive"
    },
    Power = 400
  },
  ["143749"] = {
    name = {
      "4Corrupted Nightborne Matrix"
    },
    Power = 1000
  },
  ["141888"] = {
    name = {
      "6Discarded Aristocrat's Censer"
    },
    Power = 50
  },
  ["142451"] = {
    name = {
      "5Overcharged Ward Focus"
    },
    Power = 100
  },
  ["144269"] = {
    name = {
      "6Vacant Soul Shard"
    },
    Power = 240
  },
  ["141668"] = {
    name = {
      "5The Arcanist's Codex"
    },
    Power = 300
  },
  ["141951"] = {
    name = {
      "4Spellbound Jewelry Box"
    },
    Power = 600
  },
  ["140307"] = {
    name = {
      "4Heart of Zin-Azshari"
    },
    Power = 4000
  },
  ["140237"] = {
    name = {
      "5Iadreth's Enchanted Birthstone"
    },
    Power = 350
  },
  ["139510"] = {
    name = {
      "5Black Rook Soldier's Insignia"
    },
    Power = 480
  },
  ["143680"] = {
    name = {
      "5Soldier's Esteem"
    },
    Power = 400
  },
  ["141708"] = {
    name = {
      "5Curio of Neltharion"
    },
    Power = 545
  },
  ["140250"] = {
    name = {
      "5Ingested Legion Stabilizer"
    },
    Power = 350
  },
  ["140238"] = {
    name = {
      "5Scavenged Felstone"
    },
    Power = 300
  },
  ["140518"] = {
    name = {
      "6Bottled Lightning"
    },
    Power = 100
  },
  ["141931"] = {
    name = {
      "6Tattered Farondis Heraldry"
    },
    Power = 215
  },
  ["131732"] = {
    name = {
      "4Purple Hills of Mac'Aree"
    },
    Power = 1000
  },
  ["141925"] = {
    name = {
      "6Pruned Nightmare Shoot"
    },
    Power = 190
  },
  ["143869"] = {
    name = {
      "5Accolade of Victory"
    },
    Power = 400
  },
  ["141923"] = {
    name = {
      "6Petrified Axe Haft"
    },
    Power = 195
  },
  ["143870"] = {
    name = {
      "5Accolade of Heroism"
    },
    Power = 500
  },
  ["140511"] = {
    name = {
      "6Soul Shackle"
    },
    Power = 150
  },
  ["141924"] = {
    name = {
      "6Broken Control Mechanism"
    },
    Power = 185
  },
  ["141314"] = {
    name = {
      "4Treemender's Beacon"
    },
    Power = 500
  },
  ["128021"] = {
    name = {
      "5Scroll of Enlightenment"
    },
    Power = 0
  },
  ["138814"] = {
    name = {
      "6Adventurer's Renown"
    },
    Power = 35
  },
  ["143868"] = {
    name = {
      "5Accolade of Achievement"
    },
    Power = 250
  },
  ["141672"] = {
    name = {
      "5Insignia of the Nightborne Commander"
    },
    Power = 300
  },
  ["138783"] = {
    name = {
      "6Glittering Memento"
    },
    Power = 0
  },
  ["141935"] = {
    name = {
      "5Enchrgled Mlrgmlrg of Enderglment"
    },
    Power = 300
  },
  ["141680"] = {
    name = {
      "4Titan-Forged Locket"
    },
    Power = 450
  },
  ["140252"] = {
    name = {
      "5Tel'anor Ancestral Tablet"
    },
    Power = 300
  },
  ["140524"] = {
    name = {
      "6Sharp Twilight Tooth"
    },
    Power = 150
  },
  ["141702"] = {
    name = {
      "6Spoiled Manawine Dregs"
    },
    Power = 200
  },
  ["140531"] = {
    name = {
      "6Ravencrest Family Seal"
    },
    Power = 150
  },
  ["141936"] = {
    name = {
      "5Petrified Fel-Heart"
    },
    Power = 350
  },
  ["141710"] = {
    name = {
      "5Discontinued Suramar City Key"
    },
    Power = 530
  },
  ["140460"] = {
    name = {
      "6Thisalee's Fighting Claws"
    },
    Power = 100
  },
  ["139612"] = {
    name = {
      "6Highmountain Mystic's Totem"
    },
    Power = 210
  },
  ["141852"] = {
    name = {
      "5Accolade of Heroism"
    },
    Power = 500
  },
  ["144297"] = {
    name = {
      "5Talisman of Victory"
    },
    Power = 0
  },
  ["141926"] = {
    name = {
      "6Druidic Molting"
    },
    Power = 215
  },
  ["143738"] = {
    name = {
      "4Flying Hourglass"
    },
    Power = 500
  },
  ["141952"] = {
    name = {
      "4Delving Deeper by Arcanist Perclanea"
    },
    Power = 600
  },
  ["141400"] = {
    name = {
      "5Underking's Fist"
    },
    Power = 100
  },
  ["142449"] = {
    name = {
      "5Unearthed Staff Headpiece"
    },
    Power = 100
  },
  ["141934"] = {
    name = {
      "5Partially Enchanted Nightborne Coin"
    },
    Power = 100
  },
  ["141856"] = {
    name = {
      "4History of the Ages"
    },
    Power = 400
  },
  ["140463"] = {
    name = {
      "6Broken Eredar Blade"
    },
    Power = 100
  },
  ["140372"] = {
    name = {
      "5Ancient Artificer's Manipulator"
    },
    Power = 40
  },
  ["143871"] = {
    name = {
      "5Accolade of Myth"
    },
    Power = 600
  },
  ["141889"] = {
    name = {
      "4Glory of the Melee"
    },
    Power = 500
  },
  ["141854"] = {
    name = {
      "5Accolade of Achievement"
    },
    Power = 250
  },
  ["138726"] = {
    name = {
      "6Shard of Potentiation"
    },
    Power = 0
  },
  ["140176"] = {
    name = {
      "5Accolade of Victory"
    },
    Power = 400
  },
  ["141682"] = {
    name = {
      "4Free Floating Ley Spark"
    },
    Power = 500
  },
  ["141669"] = {
    name = {
      "4Fel-Touched Tome"
    },
    Power = 300
  },
  ["140503"] = {
    name = {
      "6Blank To-Do List"
    },
    Power = 100
  },
  ["141404"] = {
    name = {
      "5Insignia of the Second Command"
    },
    Power = 100
  },
  ["138864"] = {
    name = {
      "6Skirmisher's Advantage"
    },
    Power = 50
  },
  ["138839"] = {
    name = {
      "6Valiant's Glory"
    },
    Power = 20
  },
  ["140361"] = {
    name = {
      "6Pulsating Runestone"
    },
    Power = 150
  },
  ["141933"] = {
    name = {
      "5Citrine Telemancy Index"
    },
    Power = 300
  },
  ["131763"] = {
    name = {
      "5Bundle of Trueshot Arrows"
    },
    Power = 35
  },
  ["141863"] = {
    name = {
      "5Daglop's Precious"
    },
    Power = 20
  },
  ["142450"] = {
    name = {
      "5Ley to Fel Power Converter"
    },
    Power = 100
  },
  ["142054"] = {
    name = {
      "5Enchanted Nightborne Coin"
    },
    Power = 100
  },
  ["139413"] = {
    name = {
      "4Greater Questor's Glory"
    },
    Power = 200
  },
  ["128000"] = {
    name = {
      "5Crystal of Ensoulment"
    },
    Power = 0
  },
  ["141940"] = {
    name = {
      "5Starsong's Bauble"
    },
    Power = 300
  },
  ["140247"] = {
    name = {
      "4Mornath's Enchanted Statue"
    },
    Power = 350
  },
  ["140396"] = {
    name = {
      "5Friendly Brawler's Wager"
    },
    Power = 40
  },
  ["141685"] = {
    name = {
      "4The Valewalker's Blessing"
    },
    Power = 2500
  },
  ["141684"] = {
    name = {
      "4Residual Manastorm Energy"
    },
    Power = 875
  },
  ["134118"] = {
    name = {
      "4Cluster of Potentiation"
    },
    Power = 0
  },
  ["143487"] = {
    name = {
      "4Enchanted Dusk Lily"
    },
    Power = 800
  },
  ["141390"] = {
    name = {
      "5The Corruptor's Totem"
    },
    Power = 100
  },
  ["143498"] = {
    name = {
      "4Charged Construct's Finger"
    },
    Power = 500
  },
  ["140254"] = {
    name = {
      "5The Seawarden's Beacon"
    },
    Power = 350
  },
  ["143739"] = {
    name = {
      "4Mark of the Soulcleaver"
    },
    Power = 500
  }
}

