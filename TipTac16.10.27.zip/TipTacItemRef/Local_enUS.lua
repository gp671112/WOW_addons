local L = LibStub("AceLocale-3.0"):NewLocale("TipTacItemRef", true)
if not L then return end 

-- core.lua
L["|cFFFFFFFFTarget|r"] = true;
L["|cFFFFFFFFYour Group|r"] = true;
L["(Group %s)"] = true;
L["(Group %s:%s)"] = true;
L["SpellID: %d"] = true;
L["Cast By: %s"] = true;
L["ItemLevel: %d, ItemID: %d"] = true;
L["CurrentLevel: %d, Upgrade: %s"] = true;
L["SpellID: "] = true;
L["QuestLevel: %d, QuestID: %d"] = true;
L["CurrencyID: %d"] = true;
L["Achievement Criteria |cffffffff"] = true;
L["AchievementID: %d, CategoryID: %d"] = true;