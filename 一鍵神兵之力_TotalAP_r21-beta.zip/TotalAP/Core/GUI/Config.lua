  ----------------------------------------------------------------------------------------------------------------------
    -- This program is free software: you can redistribute it and/or modify
    -- it under the terms of the GNU General Public License as published by
    -- the Free Software Foundation, either version 3 of the License, or
    -- (at your option) any later version.
	
    -- This program is distributed in the hope that it will be useful,
    -- but WITHOUT ANY WARRANTY; without even the implied warranty of
    -- MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    -- GNU General Public License for more details.

    -- You should have received a copy of the GNU General Public License
    -- along with this program.  If not, see <http://www.gnu.org/licenses/>.
----------------------------------------------------------------------------------------------------------------------


--- Aggregates any logic pertaining to the presentation of data, as well as its layout
-- @module GUI

--- Config.lua.
-- Manages the appearance, layout, and functionality of the config GUI (via AceConfig-3.0 library)
-- @section Config


-- Default settings DB (TODO: Replace defaultSettings in the current DBHandler module)

local addonName, TotalAP = ...

if not TotalAP then return end


-- TODO: What methods should be moved here from the GUI controller, if any?

-- Stub
local function CreateConfig()

end




local R = {

}

return R
