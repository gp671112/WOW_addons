local L;


-- TODO: Other locales aren't included yet. Use WowInterface/CurseForge to localise and update strings as soon as they're available (this file is temporary)

-- L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "esES"); 
-- if L then
	
-- end

-- L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "esMX"); 
-- if L then

-- end

-- L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "frFR"); 
-- if L then

-- end


-- L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "ruRU"); 
-- if L then
	
-- end

-- L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "zhCN"); 
-- if L then

-- end

-- L = LibStub("AceLocale-3.0"):NewLocale("TotalAP", "ptBR"); 
-- if L then

-- end
