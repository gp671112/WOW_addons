﻿local AL = _G.AtlasLoot.GetLocales("koKR")

if not AL then return end

-- These localization strings are translated on WoWAce: http://www.wowace.com/addons/atlasloot-enhanced/localization
AL["AtlasLoot Options"] = "AtlasLoot 옵션" -- Needs review


