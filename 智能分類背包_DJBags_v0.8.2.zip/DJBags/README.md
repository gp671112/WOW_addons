# Dark Jaguar Bags

A bag addon that sorts items into categories defined by Blizzard. 

## Features:
* Shows item level.
* MOGIT Support.
* PAWN Support.
* Clear new items with the clear items button next to search bar. ~~or by mousing over them.~~
* Restack items: Restack items for bags with the restack button.
* All bags settings for columns and categories.
* User defined settings for all chars or per char: press ALT + Left mouse button on an item to open dialogue.
* Clear a single new item: ALT + Right mouse button on new item to remove it from new items list.
