_G["BINDING_HEADER_TANKMD"] = "獵人誤導"
_G["BINDING_NAME_CLICK MisdirectTankButton:LeftButton"] = "誤導給坦克/寵物"